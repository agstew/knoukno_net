# Hostinger Deploy Notes

This project has three deployable parts:

- `knoukno-wordpress-theme.zip` - upload to Hostinger WordPress.
- `knoukno-admin-dashboard-hostinger.zip` - upload the built admin dashboard files to a static site or subdomain such as `admin.knoukno.net`.
- `knoukno-backend-hostinger.zip` - upload to Hostinger VPS or Node.js hosting for the MongoDB API.

## WordPress Website

Use Hostinger WordPress hosting for the public site.

1. Open Hostinger hPanel.
1. Open WordPress Admin for `knoukno.net`.
1. Go to Appearance > Themes > Add New > Upload Theme.
1. Upload `knoukno-wordpress-theme.zip`.
1. Activate **Kno U Kno**.
1. Go to Settings > Permalinks and click Save Changes.

## Admin Dashboard

Use a subdomain such as `admin.knoukno.net`.

1. Build with production values:

```bash
cd admin-dashboard
VITE_KNOUKNO_API_BASE=https://api.knoukno.net VITE_KNOUKNO_WEBSITE_URL=https://knoukno.net/ npm run build
```

1. Upload the contents of `admin-dashboard/dist` or upload `knoukno-admin-dashboard-hostinger.zip` to the admin subdomain public folder.

## Backend API

The backend needs Node.js plus MongoDB. Standard WordPress-only hosting is not enough for this part. Use Hostinger VPS or a Hostinger plan with Node.js support.

1. Upload `knoukno-backend-hostinger.zip`.
1. Unzip it on the server.
1. Copy `backend/.env.hostinger.example` to `backend/.env`.
1. Replace the MongoDB URI and JWT secret.
1. Install and start:

```bash
cd backend
npm install --omit=dev
npm start
```

1. After the API is running, seed MongoDB:

```bash
curl -X POST https://api.knoukno.net/setup
```

## Important

Hostinger WordPress hosting can run the WordPress theme. The MongoDB backend and React admin dashboard need separate hosting or subdomains. If only WordPress hosting is available, upload only `knoukno-wordpress-theme.zip` first.
