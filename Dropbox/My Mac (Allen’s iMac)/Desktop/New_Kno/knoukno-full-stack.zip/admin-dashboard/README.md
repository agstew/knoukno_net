# KnoUKno Admin Dashboard

React/Vite admin dashboard scaffold for the MongoDB backend.

Requested files included:

- `Admin.jsx`
- `Title.jsx`
- `List.jsx`
- `Dashboard.jsx`
- `Save.jsx`
- `Question.jsx`
- `Questions.jsx`
- `Ouestions.jsx` alias for the requested spelling
- `Example.jsx`
- `Answers.jsx`
- `SaveAnswers.jsx`
- `Grade.jsx`
- `SaveGrade.jsx`
- `GradeList.jsx`
- `Rated.jsx`
- `SaveRated.jsx`
- `RatedList.jsx`
- `Average.jsx`
- `AverageSave.jsx`
- `Print.jsx`
- `Delete.jsx`
- `SaveAll.jsx`
- `Email.jsx`

## Run

```bash
cd admin-dashboard
cp .env.example .env
npm install
npm run dev
```

By default it calls `http://localhost:5050`. Override with:

```bash
VITE_KNOUKNO_API_BASE=http://localhost:5050 npm run dev
```

For build:

```bash
npm run build
```
