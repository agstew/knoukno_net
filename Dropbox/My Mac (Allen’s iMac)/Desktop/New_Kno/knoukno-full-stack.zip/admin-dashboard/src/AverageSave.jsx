import React from 'react';
import { apiRequest } from './api.js';

export default function AverageSave({ selectedTitle }) {
  async function saveAverage() {
    await apiRequest('/averages', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
  }

  return (
    <>
      <p className="section-kicker">Average Save</p>
      <h2>Average Save</h2>
      <button type="button" onClick={saveAverage}>Average Save</button>
    </>
  );
}
