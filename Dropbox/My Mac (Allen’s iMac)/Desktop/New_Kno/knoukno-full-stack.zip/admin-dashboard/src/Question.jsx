import React from 'react';

export default function Question() {
  return (
    <>
      <p className="section-kicker">question.Js</p>
      <h2>One Question</h2>
      <p>Shows one question at a time. Use Questions.jsx for pagination across Free 5, Member 50, Pro 75, Bonus 100, Member Bonus 150, and Pro Bonus 175.</p>
    </>
  );
}
