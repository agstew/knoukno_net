import React from 'react';
import { apiRequest } from './api.js';

export default function SaveRated({ selectedTitle }) {
  async function saveRated() {
    await apiRequest('/ratings', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title', questionNumber: 1, rating: 5 }),
    });
  }

  return (
    <>
      <p className="section-kicker">Save Rated</p>
      <h2>Save Rated</h2>
      <button type="button" onClick={saveRated}>Save Rated</button>
    </>
  );
}
