import React, { useState } from 'react';
import { apiRequest } from './api.js';

export default function Average({ selectedTitle }) {
  const [average, setAverage] = useState(null);

  async function calculateAverage() {
    const result = await apiRequest('/averages', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
    setAverage(result.average);
  }

  return (
    <>
      <p className="section-kicker">Average.jsx</p>
      <h2>Average</h2>
      <p>Title: {selectedTitle?.title || 'preview-title'}</p>
      <button type="button" onClick={calculateAverage}>Average Page</button>
      <strong>{average === null ? '0%' : `${average}%`}</strong>
    </>
  );
}
