import React from 'react';
import { apiRequest } from './api.js';

export default function SaveAll({ selectedTitle }) {
  async function saveAll() {
    await apiRequest('/save-all', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
  }

  return (
    <>
      <p className="section-kicker">Save All</p>
      <h2>Save All</h2>
      <button type="button" onClick={saveAll}>Save All</button>
    </>
  );
}
