import React from 'react';
import { apiRequest } from './api.js';

export default function SaveAnswers({ selectedTitle }) {
  async function saveAnswers() {
    await apiRequest('/saves', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title', type: 'answers' }),
    });
  }

  return (
    <>
      <p className="section-kicker">Save Answers</p>
      <h2>Save Answers</h2>
      <button type="button" onClick={saveAnswers}>Save Answers</button>
    </>
  );
}
