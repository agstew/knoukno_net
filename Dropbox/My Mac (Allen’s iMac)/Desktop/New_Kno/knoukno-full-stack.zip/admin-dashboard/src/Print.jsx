import React from 'react';
import { apiRequest } from './api.js';

export default function Print({ selectedTitle }) {
  async function trackPrint() {
    await apiRequest('/prints', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
    window.print();
  }

  return (
    <>
      <p className="section-kicker">Print.jsx</p>
      <h2>Print</h2>
      <p>Tracks print events in the `prints` collection for {selectedTitle?.title || 'preview-title'}.</p>
      <button type="button" onClick={trackPrint}>Print Page</button>
    </>
  );
}
