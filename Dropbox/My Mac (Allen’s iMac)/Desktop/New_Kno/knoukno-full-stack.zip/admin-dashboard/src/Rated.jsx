import React, { useState } from 'react';
import { apiRequest } from './api.js';

export default function Rated({ selectedTitle }) {
  const [rating, setRating] = useState(0);
  const [status, setStatus] = useState('');

  async function saveRating() {
    await apiRequest('/ratings', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title', questionNumber: 1, rating }),
    });
    setStatus('Rating saved.');
  }

  return (
    <>
      <p className="section-kicker">Rated.jsx</p>
      <h2>Rated</h2>
      <p>Title: {selectedTitle?.title || 'preview-title'}</p>
      <input type="range" min="0" max="5" value={rating} onChange={(event) => setRating(event.target.value)} />
      <strong>{Number(rating).toFixed(1)} / 5</strong>
      <button type="button" onClick={saveRating}>Save Rating</button>
      <p>{status}</p>
    </>
  );
}
