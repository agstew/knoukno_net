import React, { useState } from 'react';
import { apiRequest } from './api.js';

export default function Answers({ selectedTitle }) {
  const [questionNumber, setQuestionNumber] = useState(1);
  const [answer, setAnswer] = useState('');
  const [status, setStatus] = useState('');

  async function saveAnswer() {
    await apiRequest('/answers', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title', questionNumber, answer }),
    });
    setStatus('Answer saved.');
  }

  return (
    <>
      <p className="section-kicker">Answers.jsx</p>
      <h2>Answers</h2>
      <p>Pagination: The client writes a different answer for each question. Title: {selectedTitle?.title || 'preview-title'}</p>
      <input type="number" min="1" value={questionNumber} onChange={(event) => setQuestionNumber(Number(event.target.value))} />
      <textarea value={answer} onChange={(event) => setAnswer(event.target.value)} placeholder="Client answer" />
      <button type="button" onClick={saveAnswer}>Save Answer</button>
      <p>{status}</p>
    </>
  );
}
