import React, { useEffect, useState } from 'react';
import { apiRequest } from './api.js';

const tierLimits = {
  FREE: 5,
  MEMBER: 50,
  PRO: 75,
  BONUS_100: 100,
  MEMBER_BONUS_150: 150,
  PRO_BONUS_175: 175,
  ALL_300: 300,
};

export default function Questions({ selectedTitle }) {
  const [page, setPage] = useState(1);
  const [tier, setTier] = useState('FREE');
  const [questions, setQuestions] = useState([]);
  const [examples, setExamples] = useState([]);
  const [answers, setAnswers] = useState({});
  const [status, setStatus] = useState('');
  const limit = 5;
  const maxQuestions = tierLimits[tier];
  const maxPage = Math.ceil(maxQuestions / limit);

  useEffect(() => {
    apiRequest(`/questions?page=${page}&limit=${limit}&tier=${tier}`).then((result) => setQuestions(result.questions || [])).catch(() => setQuestions([]));
    apiRequest(`/examples?page=${page}&limit=${limit}`).then((result) => setExamples(result.examples || [])).catch(() => setExamples([]));
  }, [page, tier]);

  function updateAnswer(questionNumber, value) {
    setAnswers((currentAnswers) => ({ ...currentAnswers, [questionNumber]: value }));
  }

  async function saveAnswer(questionNumber) {
    await apiRequest('/answers', {
      method: 'POST',
      body: JSON.stringify({
        titleId: selectedTitle?._id || 'preview-title',
        questionNumber,
        answer: answers[questionNumber] || '',
      }),
    });
    setStatus(`Answer saved for question ${questionNumber}.`);
  }

  return (
    <>
      <p className="section-kicker">Questions.jsx</p>
      <h2>Questions</h2>
      <p>Title: {selectedTitle?.title || 'Click a name in List.jsx first'}</p>
      <select value={tier} onChange={(event) => { setTier(event.target.value); setPage(1); }}>
        <option value="FREE">Free 1 - 5</option>
        <option value="MEMBER">Member 1 - 50</option>
        <option value="PRO">Pro 1 - 75</option>
        <option value="BONUS_100">Bonus 1 - 100</option>
        <option value="MEMBER_BONUS_150">Member Bonus 1 - 150</option>
        <option value="PRO_BONUS_175">Pro Bonus 1 - 175</option>
        <option value="ALL_300">All 300 Questions</option>
      </select>
      <p>Pagination: {((page - 1) * limit) + 1} - {Math.min(page * limit, maxQuestions)} Questions. Every question is different and focused on getting the business started and moving forward.</p>
      <div className="question-list">
        {questions.map((question) => {
          const example = examples.find((item) => item.questionNumber === question.questionNumber);

          return (
            <article className="question-row" key={question.questionNumber}>
              <h3>Question {question.questionNumber} of {maxQuestions}</h3>
              <p><strong>Question:</strong> {question.prompt}</p>
              <p><strong>Example:</strong> {example?.example || question.example}</p>
              <label>
                <strong>Answers:</strong>
                <textarea
                  value={answers[question.questionNumber] || ''}
                  onChange={(event) => updateAnswer(question.questionNumber, event.target.value)}
                  placeholder="Client answer"
                />
              </label>
              <button type="button" onClick={() => saveAnswer(question.questionNumber)}>Save Answer</button>
            </article>
          );
        })}
      </div>
      <button type="button" onClick={() => setPage(Math.max(1, page - 1))}>Back</button>
      <button type="button" onClick={() => setPage(Math.min(maxPage, page + 1))}>Next</button>
      <p>{status}</p>
    </>
  );
}
