import React from 'react';

export default function List({ titles = [], onSelectTitle, onRefreshTitles }) {
  function openQuestions(event, title) {
    event.preventDefault();
    onSelectTitle(title);
  }

  return (
    <>
      <p className="section-kicker">List.jsx</p>
      <h2>Title List</h2>
      <p>A client clicks the business name, then Questions.jsx opens for that title.</p>
      <button type="button" onClick={onRefreshTitles}>Refresh List</button>
      <ul className="title-list">
        {titles.length ? titles.map((item) => (
          <li key={item._id}>
            <a href="#questions" onClick={(event) => openQuestions(event, item)}>{item.title || 'Untitled business'}</a>
          </li>
        )) : <li>No business titles saved yet.</li>}
      </ul>
    </>
  );
}
