import React, { useState } from 'react';
import { API_BASE } from './api.js';

export default function Delete({ selectedTitle }) {
  const [titleId, setTitleId] = useState(selectedTitle?._id || 'preview-title');
  const [status, setStatus] = useState('');

  async function deleteTitle() {
    const response = await fetch(`${API_BASE}/titles/${titleId}`, {
      method: 'DELETE',
      headers: { 'x-knoukno-user-id': 'admin-preview' },
    });

    setStatus(response.ok ? 'Delete recorded.' : 'Delete failed.');
  }

  return (
    <>
      <p className="section-kicker">Delete.jsx</p>
      <h2>Delete</h2>
      <p>Selected: {selectedTitle?.title || 'preview-title'}</p>
      <input value={titleId} onChange={(event) => setTitleId(event.target.value)} placeholder="Title id" />
      <button type="button" onClick={deleteTitle}>Delete Title</button>
      <p>{status}</p>
    </>
  );
}
