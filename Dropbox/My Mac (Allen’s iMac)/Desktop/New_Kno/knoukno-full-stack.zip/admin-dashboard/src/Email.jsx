import React, { useEffect, useState } from 'react';
import { apiRequest } from './api.js';

export default function Email() {
  const [page, setPage] = useState(1);
  const [letters, setLetters] = useState([]);

  useEffect(() => {
    apiRequest(`/email-letters?page=${page}&limit=12`).then((result) => setLetters(result.letters || [])).catch(() => setLetters([]));
  }, [page]);

  return (
    <>
      <p className="section-kicker">Email</p>
      <h2>360 Client Emails</h2>
      <p>Each email letter is different and ready to send to clients.</p>
      <ol>{letters.map((letter) => <li key={letter.emailNumber}><strong>{letter.subject}</strong><br />{letter.body}</li>)}</ol>
      <button type="button" onClick={() => setPage(Math.max(1, page - 1))}>Back</button>
      <button type="button" onClick={() => setPage(page + 1)}>Next</button>
    </>
  );
}
