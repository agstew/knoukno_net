import React, { useState } from 'react';
import { apiRequest } from './api.js';

export default function Grade({ selectedTitle }) {
  const [grade, setGrade] = useState(null);

  async function calculateGrade() {
    const result = await apiRequest('/grades', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
    setGrade(result.grade);
  }

  return (
    <>
      <p className="section-kicker">Grade.jsx</p>
      <h2>Grade</h2>
      <p>Title: {selectedTitle?.title || 'preview-title'}</p>
      <button type="button" onClick={calculateGrade}>Grade Page</button>
      <strong>{grade === null ? '0%' : `${grade}%`}</strong>
    </>
  );
}
