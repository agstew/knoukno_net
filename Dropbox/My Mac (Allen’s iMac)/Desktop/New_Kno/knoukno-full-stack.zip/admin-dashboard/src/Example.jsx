import React, { useEffect, useState } from 'react';
import { apiRequest } from './api.js';

export default function Example() {
  const [page, setPage] = useState(1);
  const [examples, setExamples] = useState([]);

  useEffect(() => {
    apiRequest(`/examples?page=${page}&limit=5`).then((result) => setExamples(result.examples || [])).catch(() => setExamples([]));
  }, [page]);

  return (
    <>
      <p className="section-kicker">Example.jsx</p>
      <h2>Example</h2>
      <p>Pagination: AI-generated example answers, each different.</p>
      <ol>{examples.map((example) => <li key={example.questionNumber}>{example.example}</li>)}</ol>
      <button type="button" onClick={() => setPage(Math.max(1, page - 1))}>Back</button>
      <button type="button" onClick={() => setPage(page + 1)}>Next</button>
    </>
  );
}
