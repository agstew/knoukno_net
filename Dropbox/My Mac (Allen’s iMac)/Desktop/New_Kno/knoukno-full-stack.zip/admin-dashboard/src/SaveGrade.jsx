import React from 'react';
import { apiRequest } from './api.js';

export default function SaveGrade({ selectedTitle }) {
  async function saveGrade() {
    await apiRequest('/grades', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
  }

  return (
    <>
      <p className="section-kicker">Save Grade</p>
      <h2>Save Grade</h2>
      <button type="button" onClick={saveGrade}>Save Grade</button>
    </>
  );
}
