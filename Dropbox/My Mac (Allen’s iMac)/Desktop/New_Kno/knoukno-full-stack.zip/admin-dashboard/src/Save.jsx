import React from 'react';
import { apiRequest } from './api.js';

export default function Save({ selectedTitle }) {
  async function savePage() {
    await apiRequest('/saves', {
      method: 'POST',
      body: JSON.stringify({ titleId: selectedTitle?._id || 'preview-title' }),
    });
  }

  return (
    <>
      <p className="section-kicker">save.Js</p>
      <h2>Save</h2>
      <p>Save page event for {selectedTitle?.title || 'preview-title'}.</p>
      <button type="button" onClick={savePage}>Save Page</button>
    </>
  );
}
