import React, { useEffect, useState } from 'react';
import Dashboard from './Dashboard.jsx';
import Save from './Save.jsx';
import Title from './Title.jsx';
import List from './List.jsx';
import Question from './Question.jsx';
import Questions from './Questions.jsx';
import Example from './Example.jsx';
import Answers from './Answers.jsx';
import Grade from './Grade.jsx';
import GradeList from './GradeList.jsx';
import Rated from './Rated.jsx';
import RatedList from './RatedList.jsx';
import Average from './Average.jsx';
import Print from './Print.jsx';
import Delete from './Delete.jsx';
import SaveAnswers from './SaveAnswers.jsx';
import SaveGrade from './SaveGrade.jsx';
import SaveRated from './SaveRated.jsx';
import AverageSave from './AverageSave.jsx';
import SaveAll from './SaveAll.jsx';
import Email from './Email.jsx';
import { apiRequest } from './api.js';

const websiteUrl = import.meta.env.VITE_KNOUKNO_WEBSITE_URL || 'http://localhost:8080/';

const sections = [
  ['Dashboard', Dashboard],
  ['Title', Title],
  ['List', List],
  ['Save', Save],
  ['Question', Question],
  ['Questions', Questions],
  ['Example', Example],
  ['Answers', Answers],
  ['Save Answers', SaveAnswers],
  ['Grade', Grade],
  ['Save Grade', SaveGrade],
  ['Grade List', GradeList],
  ['Rated', Rated],
  ['Save Rated', SaveRated],
  ['Rated List', RatedList],
  ['Average', Average],
  ['Average Save', AverageSave],
  ['Print', Print],
  ['Delete', Delete],
  ['Save All', SaveAll],
  ['Email', Email],
];

function sectionId(label) {
  return label.toLowerCase().replaceAll(' ', '-');
}

function getActiveSectionId() {
  return window.location.hash.replace('#', '') || 'dashboard';
}

export default function Admin() {
  const [selectedTitle, setSelectedTitle] = useState(null);
  const [titles, setTitles] = useState([]);
  const [activeSectionId, setActiveSectionId] = useState(getActiveSectionId);

  function loadTitles() {
    apiRequest('/titles').then((result) => setTitles(result.titles || [])).catch(() => setTitles([]));
  }

  function selectTitle(title) {
    setSelectedTitle(title);
    window.location.hash = 'questions';
  }

  function addSavedTitle(title) {
    setTitles((currentTitles) => [title, ...currentTitles.filter((item) => item._id !== title._id)]);
    selectTitle(title);
  }

  useEffect(() => {
    loadTitles();
  }, []);

  useEffect(() => {
    function syncActiveSection() {
      setActiveSectionId(getActiveSectionId());
    }

    window.addEventListener('hashchange', syncActiveSection);
    return () => window.removeEventListener('hashchange', syncActiveSection);
  }, []);

  const activeSection = sections.find(([label]) => sectionId(label) === activeSectionId) || sections[0];
  const [activeLabel, ActiveComponent] = activeSection;
  const shouldShowActiveSection = sectionId(activeLabel) !== 'dashboard';

  return (
    <main className="admin-shell">
      <header className="admin-header">
        <p>KnoUKno Admin</p>
        <h1>MongoDB Dashboard</h1>
      </header>
      <nav className="admin-nav" aria-label="Admin sections">
        <a className="website-link" href={websiteUrl}>Website</a>
        {sections.map(([label]) => (
          <a className={sectionId(label) === activeSectionId ? 'is-active' : ''} key={label} href={`#${sectionId(label)}`}>{label}</a>
        ))}
      </nav>
      {shouldShowActiveSection ? (
        <section className="admin-card admin-card--active" id={sectionId(activeLabel)}>
          <ActiveComponent
            selectedTitle={selectedTitle}
            titles={titles}
            onSelectTitle={selectTitle}
            onTitleSaved={addSavedTitle}
            onRefreshTitles={loadTitles}
          />
        </section>
      ) : null}
    </main>
  );
}
