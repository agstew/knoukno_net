import React from 'react';

export default function RatedList() {
  return (
    <>
      <p className="section-kicker">RatedList.jsx</p>
      <h2>Rated List</h2>
      <p>List rating records from the `ratings` collection by user, title, and question number.</p>
    </>
  );
}
