export const API_BASE = import.meta.env.VITE_KNOUKNO_API_BASE || 'http://localhost:5050';

function getStoredToken() {
  if (typeof window === 'undefined') {
    return '';
  }

  return window.localStorage.getItem('knouknoToken') || '';
}

export async function apiRequest(path, options = {}) {
  const token = getStoredToken();
  const headers = {
    'Content-Type': 'application/json',
    'x-knoukno-user-id': options.userId || 'admin-preview',
    ...options.headers,
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
    delete headers['x-knoukno-user-id'];
  }

  const response = await fetch(`${API_BASE}${path}`, {
    headers,
    ...options,
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.status}`);
  }

  return response.json();
}
