import React from 'react';

export default function GradeList() {
  return (
    <>
      <p className="section-kicker">GradeList.jsx</p>
      <h2>Grade List</h2>
      <p>List grade snapshots from the `grades` collection by user and business title.</p>
    </>
  );
}
