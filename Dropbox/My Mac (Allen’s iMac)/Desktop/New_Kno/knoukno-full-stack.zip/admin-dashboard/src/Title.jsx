import React, { useState } from 'react';
import { apiRequest } from './api.js';

export default function Title({ onTitleSaved }) {
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('');

  async function saveTitle() {
    if (!title.trim()) {
      setStatus('Write a business title first.');
      return;
    }

    const result = await apiRequest('/titles', {
      method: 'POST',
      body: JSON.stringify({ title }),
    });
    setStatus(`Saved title: ${result.title}. It is now in List.jsx.`);
    setTitle('');
    onTitleSaved?.(result);
  }

  return (
    <>
      <p className="section-kicker">Title.jsx</p>
      <h2>Title</h2>
      <p>Write the client business name. Saving sends it to List.jsx and selects it for Questions.jsx.</p>
      <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Title for the Business" />
      <button type="button" onClick={saveTitle}>Save Title</button>
      <p>{status}</p>
    </>
  );
}
