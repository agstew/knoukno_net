(function () {
  const nav = document.querySelector('[data-main-nav]');
  const toggle = document.querySelector('[data-main-nav-toggle]');

  if (!nav || !toggle) {
    return;
  }

  toggle.addEventListener('click', function () {
    const isOpen = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  });
})();

(function () {
  const fillButton = document.querySelector('[data-demo-login-fill]');
  const loginInput = document.getElementById('knoukno-login');
  const passwordInput = document.getElementById('knoukno-password');

  if (!fillButton || !loginInput || !passwordInput) {
    return;
  }

  fillButton.addEventListener('click', function () {
    loginInput.value = fillButton.getAttribute('data-demo-email') || '';
    passwordInput.value = fillButton.getAttribute('data-demo-password') || '';
    passwordInput.type = 'text';

    const toggle = document.querySelector('[data-password-toggle="knoukno-password"]');
    if (toggle) {
      toggle.setAttribute('aria-label', 'Hide password');
      toggle.setAttribute('aria-pressed', 'true');
    }
  });
})();

(function () {
  const toggles = document.querySelectorAll('[data-password-toggle]');

  toggles.forEach(function (toggle) {
    const input = document.getElementById(toggle.getAttribute('data-password-toggle'));

    if (!input) {
      return;
    }

    toggle.addEventListener('click', function () {
      const shouldShow = input.type === 'password';
      input.type = shouldShow ? 'text' : 'password';
      toggle.setAttribute('aria-label', shouldShow ? 'Hide password' : 'Show password');
      toggle.setAttribute('aria-pressed', String(shouldShow));
    });
  });
})();

(function () {
  const workspace = document.querySelector('[data-client-workspace]');

  if (!workspace) {
    return;
  }

  const userId = workspace.getAttribute('data-workspace-user') || 'guest';
  const storageKey = `knoukno-workspace-${userId}`;
  const titleInput = workspace.querySelector('[data-business-title]');
  const answers = Array.from(workspace.querySelectorAll('[data-answer]'));
  const rates = Array.from(workspace.querySelectorAll('[data-rate]'));
  const answerGradeSelects = Array.from(workspace.querySelectorAll('[data-answer-grade]'));
  const saveTitleButton = workspace.querySelector('[data-save-title]');
  const saveAnswerButtons = Array.from(workspace.querySelectorAll('[data-save-answer]'));
  const saveButton = workspace.querySelector('[data-save-workspace]');
  const printButton = workspace.querySelector('[data-print-workspace]');
  const gradeButton = workspace.querySelector('[data-grade-workspace]');
  const gradeOutput = workspace.querySelector('[data-grade-output]');
  const rateOutput = workspace.querySelector('[data-rate-output]');
  const averageOutput = workspace.querySelector('[data-average-output]');
  const businessList = workspace.querySelector('[data-business-list]');
  const status = workspace.querySelector('[data-workspace-status]');
  const workspaceConfig = window.knouknoWorkspace || {};
  const saveButtons = Array.from(workspace.querySelectorAll('[data-save-workspace]'));
  const printButtons = Array.from(workspace.querySelectorAll('[data-print-workspace]'));
  const gradeButtons = Array.from(workspace.querySelectorAll('[data-grade-workspace]'));
  const deleteButtons = Array.from(workspace.querySelectorAll('[data-delete-workspace]'));

  function getSavedWorkspace() {
    const raw = window.localStorage.getItem(storageKey);

    if (!raw) {
      return { title: '', answers: [], rates: [], manualGrade: '', answerGrades: [] };
    }

    try {
      return JSON.parse(raw);
    } catch (error) {
      window.localStorage.removeItem(storageKey);
      return { title: '', answers: [], rates: [], manualGrade: '', answerGrades: [] };
    }
  }

  function setSavedWorkspace(payload) {
    window.localStorage.setItem(storageKey, JSON.stringify(payload));
  }

  function applyWorkspace(payload) {
    if (titleInput) {
      titleInput.value = payload.title || '';
    }

    answers.forEach((answer, index) => {
      answer.value = payload.answers && payload.answers[index] ? payload.answers[index] : '';
    });

    rates.forEach((rate, index) => {
      rate.value = payload.rates && payload.rates[index] ? payload.rates[index] : '0';
      const output = rate.parentElement ? rate.parentElement.querySelector('output') : null;

      if (output) {
        output.textContent = rate.value;
      }
    });

    answerGradeSelects.forEach((select, index) => {
      select.value = payload.answerGrades && payload.answerGrades[index] ? payload.answerGrades[index] : payload.manualGrade || payload.gradeLetter || 'F';
    });

    updateScores();
  }

  function updateScores() {
    const saved = getSavedWorkspace();
    const answerValues = answers.length ? answers.map((answer) => answer.value) : saved.answers || [];
    const rateValues = rates.length ? rates.map((rate) => rate.value) : saved.rates || [];
    const gradeLetters = ['F', 'D', 'C', 'B', 'A'];
    const answerGradeValues = answerGradeSelects.length ? answerGradeSelects.map((select) => select.value) : saved.answerGrades || [];
    const answerGradePoints = answerGradeValues.map((gradeValue) => gradeLetters.indexOf(gradeValue)).filter((gradePoint) => gradePoint >= 0);
    const answered = answerValues.filter((answer) => String(answer || '').trim().length > 0).length;
    const questionCount = Math.max(answerValues.length || 5, 1);
    const grade = answerGradePoints.length ? Math.round(answerGradePoints.reduce((total, gradePoint) => total + gradePoint, 0) / answerGradePoints.length) : Math.round((answered / questionCount) * 4);
    const gradeLetter = gradeLetters[grade] || 'F';
    const rateTotal = rateValues.reduce((total, rate) => total + Number(rate || 0), 0);
    const rateAverage = rateValues.length ? rateTotal / rateValues.length : 0;
    const average = Math.round((((grade / 4) * 100) + ((rateAverage / 5) * 100)) / 2);

    if (gradeOutput) {
      gradeOutput.textContent = `${gradeLetter} = ${grade}`;
    }

    if (rateOutput) {
      rateOutput.textContent = `${rateAverage.toFixed(1)} / 5`;
    }

    if (averageOutput) {
      averageOutput.textContent = `${average}%`;
    }
  }

  function saveWorkspace(successMessage = 'Page saved in database.') {
    const saved = getSavedWorkspace();
    const payload = {
      title: titleInput ? titleInput.value : saved.title || '',
      answers: answers.length ? answers.map((answer) => answer.value) : saved.answers || [],
      rates: rates.length ? rates.map((rate) => rate.value) : saved.rates || [],
      manualGrade: gradeOutput ? gradeOutput.textContent.trim().charAt(0) : saved.manualGrade || '',
      answerGrades: answerGradeSelects.length ? answerGradeSelects.map((select) => select.value) : saved.answerGrades || [],
    };

    setSavedWorkspace(payload);
    updateScores();

    if (!workspaceConfig.ajaxUrl || !workspaceConfig.nonce || !workspaceConfig.isLoggedIn) {
      if (status) {
        status.textContent = 'Page saved in this browser.';
      }

      return Promise.resolve(payload);
    }

    if (status) {
      status.textContent = 'Saving to database...';
    }

    const body = new window.FormData();
    body.append('action', 'knoukno_save_workspace');
    body.append('nonce', workspaceConfig.nonce);
    body.append('workspace', JSON.stringify(payload));

    return window.fetch(workspaceConfig.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body,
    })
      .then((response) => response.json())
      .then((result) => {
        if (!result || !result.success) {
          throw new Error('Database save failed.');
        }

        setSavedWorkspace(result.data);
        applyWorkspace(result.data);

        if (result.data && result.data.title) {
          addBusinessTitleToList(result.data.title);
        }

        if (status) {
          status.textContent = successMessage;
        }

        return result.data;
      })
      .catch(() => {
        if (status) {
          status.textContent = 'Database save failed. Browser backup saved.';
        }

        return payload;
      });
  }

  function getQuestionsUrl(title) {
    return `${window.location.origin}/questions/?business=${encodeURIComponent(String(title).trim())}`;
  }

  function openQuestionsForTitle(title) {
    const cleanTitle = String(title || '').trim();

    if (!cleanTitle) {
      return;
    }

    window.location.href = getQuestionsUrl(cleanTitle);
  }

  function addBusinessTitleToList(title) {
    if (!businessList || !title) {
      return;
    }

    const cleanTitle = String(title).trim();

    if (!cleanTitle) {
      return;
    }

    const emptyItem = businessList.querySelector('[data-empty-business-list]');

    if (emptyItem) {
      emptyItem.remove();
    }

    Array.from(businessList.querySelectorAll('li')).forEach((item) => {
      const titleElement = item.querySelector('.business-title-link') || item.querySelector('span');
      const itemTitle = titleElement ? titleElement.textContent : item.textContent;

      if (itemTitle.trim().toLowerCase() === cleanTitle.toLowerCase()) {
        item.remove();
      }
    });

    const item = document.createElement('li');
    const label = document.createElement('a');
    const link = document.createElement('a');
    const questionsUrl = getQuestionsUrl(cleanTitle);

    item.className = 'business-list-row';
    item.setAttribute('data-business-href', questionsUrl);
    item.tabIndex = 0;
    label.className = 'business-title-link';
    label.href = questionsUrl;
    label.textContent = cleanTitle;
    link.href = questionsUrl;
    link.textContent = 'Questions';
    item.appendChild(label);
    item.appendChild(link);
    businessList.prepend(item);
  }

  function openBusinessRow(target) {
    const row = target.closest('[data-business-href]');

    if (!row) {
      return;
    }

    window.location.href = row.getAttribute('data-business-href');
  }

  function loadWorkspace() {
    const payload = getSavedWorkspace();

    if (!payload.title && (!payload.answers || !payload.answers.length) && (!payload.rates || !payload.rates.length)) {
      updateScores();
      return;
    }

    applyWorkspace(payload);
  }

  function loadDatabaseWorkspace() {
    if (!workspaceConfig.ajaxUrl || !workspaceConfig.nonce || !workspaceConfig.isLoggedIn) {
      return;
    }

    const body = new window.FormData();
    body.append('action', 'knoukno_load_workspace');
    body.append('nonce', workspaceConfig.nonce);

    window.fetch(workspaceConfig.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body,
    })
      .then((response) => response.json())
      .then((result) => {
        if (!result || !result.success) {
          return;
        }

        setSavedWorkspace(result.data);
        applyWorkspace(result.data);
      })
      .catch(() => {});
  }

  rates.forEach((rate) => {
    const output = rate.parentElement ? rate.parentElement.querySelector('output') : null;

    function handleRateChange() {
      if (output) {
        output.textContent = rate.value;
      }

      updateScores();
    }

    rate.addEventListener('input', handleRateChange);
    rate.addEventListener('change', handleRateChange);
  });

  answers.forEach((answer) => {
    answer.addEventListener('input', updateScores);
  });

  answerGradeSelects.forEach((select) => {
    select.addEventListener('change', updateScores);
  });

  saveButtons.forEach((button) => {
    button.addEventListener('click', function () {
      saveWorkspace(`${button.textContent.trim() || 'Page'} saved in database.`);
    });
  });

  if (saveTitleButton) {
    saveTitleButton.addEventListener('click', function () {
      saveWorkspace('Business title saved in database.').then(function (savedWorkspace) {
        if (status && savedWorkspace.title) {
          status.textContent = 'Business title saved. Click it in the list to open Questions.';
        }
      });
    });
  }

  saveAnswerButtons.forEach((button, index) => {
    button.addEventListener('click', function () {
      saveWorkspace(`Answer ${index + 1} saved in database.`);
    });
  });

  gradeButtons.forEach((button) => {
    button.addEventListener('click', function () {
      updateScores();
      saveWorkspace(`${button.textContent.trim() || 'Grade'} saved in database.`);
    });
  });

  printButtons.forEach((button) => {
    button.addEventListener('click', function () {
      saveWorkspace('Page saved for printing.');
      window.print();
    });
  });

  deleteButtons.forEach((button) => {
    button.addEventListener('click', function () {
      window.localStorage.removeItem(storageKey);
      applyWorkspace({ title: '', answers: [], rates: [] });

      if (status) {
        status.textContent = `${button.textContent.trim() || 'Workspace'} cleared in this browser.`;
      }
    });
  });

  if (businessList) {
    businessList.addEventListener('click', function (event) {
      openBusinessRow(event.target);
    });

    businessList.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') {
        return;
      }

      event.preventDefault();
      openBusinessRow(event.target);
    });
  }

  loadWorkspace();
  loadDatabaseWorkspace();
})();
