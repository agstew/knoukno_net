(function () {
  const banner = document.querySelector('[data-cookie-banner]');

  if (!banner || window.localStorage.getItem('knoukno_cookie_choice')) {
    return;
  }

  banner.hidden = false;

  banner.addEventListener('click', function (event) {
    if (!event.target.matches('[data-cookie-accept], [data-cookie-dismiss]')) {
      return;
    }

    const choice = event.target.matches('[data-cookie-accept]') ? 'accepted' : 'dismissed';
    window.localStorage.setItem('knoukno_cookie_choice', choice);
    banner.hidden = true;
  });
})();
