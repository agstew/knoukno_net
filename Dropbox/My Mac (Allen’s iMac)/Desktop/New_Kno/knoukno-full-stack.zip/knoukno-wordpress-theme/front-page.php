<?php
/**
 * Front page template.
 */
get_header();

$home_cards = [
    [
        'title' => 'AI Business Title',
        'text' => 'Register, name the business, and keep every answer organized under one title.',
        'image' => 'img/people-real-1.jpg',
        'alt' => 'Business founder setting a title',
    ],
    [
        'title' => 'Questions and Answers',
        'text' => 'Use guided prompts, write answers in text areas, and save the planning page.',
        'image' => 'img/people-real-2.jpg',
        'alt' => 'Founder answering AI planning questions',
    ],
    [
        'title' => 'Print, Grade, Rate',
        'text' => 'Print the page, grade the work, rate the answers, and watch the average improve.',
        'image' => 'img/people-founders-3.svg',
        'alt' => 'Business score and growth planning',
    ],
];

$ai_copy = 'KnoUKno.net is an AI business planning website for people who want to register, write a clear business title, answer focused questions, and turn those answers into a working plan. The site starts simple because every user must be registered before using the client workspace. After registration, the dashboard gives the founder five starter questions, five answer boxes, save controls, print controls, rating, grading, and an average score. The free tier lets a new user test five questions for three days. Member and Pro tiers unlock more questions, stronger planning depth, and bonus question packs for founders who are ready to move faster. The experience is built around practical business steps: name the idea, explain the customer, define the offer, plan the location or online channel, and write the next action. AI helps shape the thinking, but the founder owns the answers. KnoUKno.net keeps the page clean, direct, and useful, with dodgerblue action, gold highlights, white space, and black contrast. It is not a confusing app maze. It is a guided workspace where a new business owner can write, save, print, review, and improve. The goal is to help people move from a loose idea to a sharper plan they can explain, price, and build.';

$pillars = [
    ['name' => 'LAW', 'detail' => 'Entity, permits, protection, and compliance basics.', 'image' => 'img/law-icon.svg', 'alt' => 'Law icon'],
    ['name' => 'LOCATION', 'detail' => 'Physical place, online channel, customer access, and demand.', 'image' => 'img/location-icon.svg', 'alt' => 'Location icon'],
    ['name' => 'HIRING', 'detail' => 'Roles, interview questions, training, and service standards.', 'image' => 'img/hiring-icon.svg', 'alt' => 'Hiring icon'],
    ['name' => 'CUSTOMER', 'detail' => 'Audience, promise, support, follow-up, and growth.', 'image' => 'img/customer-icon.svg', 'alt' => 'Customer icon'],
];
?>

<section class="hero-section ai-hero">
    <div class="hero-content ai-hero-content">
        <p class="hero-eyebrow">A.I. Business Website</p>
        <h1>KnoUKno.net</h1>
        <p class="hero-sub">Register first, then build your business title, questions, answers, grade, rate, average, save, and print page.</p>
        <div class="hero-cta-row">
            <a href="<?php echo esc_url(home_url('/register/')); ?>" class="btn-primary-lg">Register</a>
            <a href="<?php echo esc_url(home_url('/pricing/')); ?>" class="btn-outline-lg btn-outline-lg--on-dark">Price</a>
        </div>
    </div>
    <div class="ai-hero-gallery" aria-label="KnoUKno.net AI planning images">
        <?php foreach ($home_cards as $card) : ?>
            <img src="<?php echo knoukno_asset_url($card['image']); ?>" alt="<?php echo esc_attr($card['alt']); ?>">
        <?php endforeach; ?>
    </div>
</section>

<div class="home-main ai-home-main">
    <section class="section-wrap ai-copy-section">
        <div class="section-head">
            <p class="section-eyebrow">Home</p>
            <h2 class="section-title">AI writes with you, but the business belongs to you</h2>
        </div>
        <article class="panel ai-copy-card">
            <p><?php echo esc_html($ai_copy); ?></p>
        </article>
    </section>

    <section class="section-wrap">
        <div class="section-head">
            <p class="section-eyebrow">Home Cards</p>
            <h2 class="section-title">The registered client workspace</h2>
        </div>
        <div class="home-card-grid">
            <?php foreach ($home_cards as $card) : ?>
                <article class="panel home-feature-card">
                    <img src="<?php echo knoukno_asset_url($card['image']); ?>" alt="<?php echo esc_attr($card['alt']); ?>">
                    <h3><?php echo esc_html($card['title']); ?></h3>
                    <p><?php echo esc_html($card['text']); ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section-wrap">
        <div class="section-head">
            <p class="section-eyebrow">Frontend Client</p>
            <h2 class="section-title">Five starter questions before upgrade</h2>
        </div>
        <div class="roadmap-strip">
            <?php foreach ($pillars as $pillar) : ?>
                <article class="roadmap-step">
                    <img class="roadmap-step-image" src="<?php echo knoukno_asset_url($pillar['image']); ?>" alt="<?php echo esc_attr($pillar['alt']); ?>">
                    <h3><?php echo esc_html($pillar['name']); ?></h3>
                    <p><?php echo esc_html($pillar['detail']); ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="cta-banner">
        <div class="cta-banner-inner">
            <h2>Everyone has to register</h2>
            <p>Free starts with 5 questions for 3 days. Member, Pro, and Bonus tiers unlock more planning.</p>
            <div class="hero-cta-row">
                <a href="<?php echo esc_url(home_url('/register/')); ?>" class="btn-primary-lg">Register</a>
                <a href="<?php echo esc_url(home_url('/login/')); ?>" class="btn-outline-lg btn-outline-lg--on-dark">Login</a>
            </div>
        </div>
    </section>
</div>

<?php get_footer(); ?>
