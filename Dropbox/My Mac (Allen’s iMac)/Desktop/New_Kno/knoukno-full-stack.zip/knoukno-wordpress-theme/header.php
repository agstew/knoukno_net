<?php
/**
 * Theme header.
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="site-shell">
    <header class="main-nav" data-main-nav>
        <div class="main-nav-inner">
            <a class="main-nav-brand" href="<?php echo esc_url(home_url('/')); ?>">Kno U Kno</a>
            <button type="button" class="main-nav-toggle" aria-label="Open menu" aria-expanded="false" data-main-nav-toggle>
                <span></span><span></span><span></span>
            </button>
            <nav class="main-nav-links" aria-label="<?php esc_attr_e('Primary navigation', 'knoukno'); ?>">
                <?php knoukno_default_nav(); ?>
            </nav>
        </div>
    </header>
    <main class="site-main">
