<?php
/**
 * Template Name: Dashboard
 */

if (!is_user_logged_in()) {
    wp_safe_redirect(home_url('/login/'));
    exit;
}

$current_user = wp_get_current_user();
$display_name = $current_user->display_name ?: $current_user->user_login;
$business_titles = knoukno_get_business_titles($current_user->ID);
$questions = [
    'What is the title of your business and what problem does it solve?',
    'Who is your best customer and why will that person choose you?',
    'What product or service are you selling first?',
    'Where will customers find you: location, website, social, referral, or all of them?',
    'What is the next action you must finish in the next 3 days?',
];
$examples = [
    'Kno U Kno helps new founders turn a loose business idea into a saved plan with questions, answers, grades, ratings, and next steps.',
    'My best customer is a first-time business owner who needs clear prompts before spending money on tools, ads, or hiring.',
    'The first service is a guided setup session that creates the business title, customer notes, first offer, and action list.',
    'Customers can find the business on the website first, then through referrals, local outreach, and follow-up emails.',
    'The next action is to finish the five starter answers, save the page, print it, and choose whether to upgrade.',
];

get_header();
?>

<section class="page-section content-page dashboard-page client-workspace" data-client-workspace data-workspace-user="<?php echo esc_attr($current_user->ID); ?>">
    <div class="dashboard-header panel">
        <div>
            <p class="section-eyebrow">Frontend Client</p>
            <h1>Welcome, <?php echo esc_html($display_name); ?></h1>
            <p>Everyone has to register before using the AI questions page.</p>
        </div>
        <div class="hero-cta-row">
            <a href="<?php echo esc_url(home_url('/pricing/')); ?>" class="btn-primary-lg">Price</a>
            <a href="<?php echo esc_url(wp_logout_url(home_url('/login/'))); ?>" class="btn-outline-lg">Logout</a>
        </div>
    </div>

    <?php knoukno_workspace_nav(''); ?>

    <nav class="dashboard-action-nav panel" aria-label="Dashboard actions">
        <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/title/')); ?>">Title</a>
        <a class="btn-outline-lg" href="#dashboard-answers">Answers</a>
        <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/questions/')); ?>">Question</a>
        <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/grade/')); ?>">Grade</a>
        <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/rate/')); ?>">Rated</a>
        <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/average/')); ?>">Average</a>
        <button type="button" class="btn-primary-lg" data-save-workspace>Save</button>
        <button type="button" class="btn-outline-lg" data-print-workspace>Print</button>
        <button type="button" class="btn-outline-lg" data-save-workspace>Save Answers</button>
        <button type="button" class="btn-outline-lg" data-grade-workspace>Save Grade</button>
        <button type="button" class="btn-outline-lg" data-save-workspace>Save Rated</button>
        <button type="button" class="btn-outline-lg" data-save-workspace>Average Save</button>
        <button type="button" class="btn-primary-lg" data-save-workspace>Save All</button>
        <button type="button" class="btn-outline-lg dashboard-delete-button" data-delete-workspace>Delete</button>
    </nav>

    <div class="client-toolbar panel">
        <ul class="client-scoreboard client-scoreboard--list" aria-live="polite">
            <li class="form-field business-title-field">
                <span>Title for the Business</span>
                <label class="screen-reader-text" for="business-title">Title for the Business</label>
                <div class="business-title-control">
                    <input id="business-title" name="business-title" type="text" placeholder="Example: KnoUKno AI Planning" data-business-title>
                    <button type="button" class="btn-primary-lg" data-save-title>Save Title</button>
                </div>
            </li>
            <li><span>Pagination</span><strong>1 - 5 Questions</strong></li>
            <li><span>Grade Page</span><strong data-grade-output>20%</strong></li>
            <li><span>Rate Page</span><strong data-rate-output>0.0 / 5</strong></li>
            <li><span>Average Page</span><strong data-average-output>10%</strong></li>
        </ul>

        <div class="business-list-block business-list-block--dashboard">
            <h2>Business Title List</h2>
            <p>Click Open Questions to continue with that business title.</p>
            <ul class="business-list" data-business-list>
                <?php if ($business_titles) : ?>
                    <?php foreach ($business_titles as $business_title) : ?>
                        <?php $questions_url = add_query_arg('business', rawurlencode($business_title['title']), home_url('/questions/')); ?>
                        <li class="business-list-row" data-business-href="<?php echo esc_url($questions_url); ?>" tabindex="0">
                            <a class="business-title-link" href="<?php echo esc_url($questions_url); ?>"><?php echo esc_html($business_title['title']); ?></a>
                            <a href="<?php echo esc_url($questions_url); ?>">Open Questions</a>
                        </li>
                    <?php endforeach; ?>
                <?php else : ?>
                    <li data-empty-business-list>No business titles saved yet.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <form class="question-workspace panel" id="dashboard-answers" data-question-form>
        <div class="question-workspace-head">
            <div>
                <p class="section-eyebrow">Free Tier</p>
                <h2>Pagination: 1 - 5 Questions</h2>
            </div>
            <p>Write 5 answers in the text areas, then save or print the page.</p>
        </div>

        <?php foreach ($questions as $index => $question) : ?>
            <article class="question-card" data-question-card>
                <div class="question-card-head">
                    <span><?php echo esc_html((string) ($index + 1)); ?></span>
                    <div>
                        <p class="question-meta-label">Question</p>
                        <h3><?php echo esc_html($question); ?></h3>
                    </div>
                </div>
                <p class="question-example"><span>Example</span><?php echo esc_html($examples[$index]); ?></p>
                <label class="answer-label" for="answer-<?php echo esc_attr((string) ($index + 1)); ?>">Answers</label>
                <textarea id="answer-<?php echo esc_attr((string) ($index + 1)); ?>" rows="5" placeholder="Write answer <?php echo esc_attr((string) ($index + 1)); ?> here" data-answer></textarea>
                <button type="button" class="btn-outline-lg save-answer-button" data-save-answer>Save Answer</button>
                <div class="rate-row">
                    <label for="rate-<?php echo esc_attr((string) ($index + 1)); ?>">Rate answer</label>
                    <input id="rate-<?php echo esc_attr((string) ($index + 1)); ?>" type="range" min="0" max="5" step="1" value="0" data-rate>
                    <output>0</output>
                </div>
            </article>
        <?php endforeach; ?>

        <div class="workspace-actions">
            <button type="button" class="btn-primary-lg" data-save-workspace>Save Page</button>
            <button type="button" class="btn-outline-lg" data-print-workspace>Print Page</button>
            <button type="button" class="btn-outline-lg" data-grade-workspace>Grade Page</button>
        </div>
        <p class="workspace-status" data-workspace-status>Saved answers go into the WordPress database for the registered user.</p>
    </form>

    <div class="dashboard-grid">
        <article class="panel dashboard-card">
            <h2>Profile</h2>
            <div class="dashboard-meta">
                <p><span>Email</span><?php echo esc_html($current_user->user_email); ?></p>
                <p><span>Username</span><?php echo esc_html($current_user->user_login); ?></p>
                <p><span>Admin Email</span><?php echo esc_html(get_option('admin_email')); ?></p>
            </div>
        </article>

        <article class="panel dashboard-card">
            <h2>Tier Rules</h2>
            <ul>
                <li>Free tier: 5 questions for 3 days.</li>
                <li>Member: 50 questions per month.</li>
                <li>Pro: 75 questions per year.</li>
                <li>Bonus: 150 or 175 questions for $100.00 if you buy now.</li>
            </ul>
        </article>
    </div>
</section>

<?php get_footer(); ?>
