<?php
/**
 * Template Name: Hiring
 *
 * Public hiring page for the WordPress site.
 */
get_header();
?>

<section class="hero-section hero-section--compact">
    <div class="hero-content">
        <p class="hero-eyebrow">Hiring</p>
        <h1>Hire people online. Let AI write the listing.</h1>
        <p class="hero-sub">Describe the role and what matters to you. Kno U Kno helps turn that into a clean, ready-to-post job listing.</p>
    </div>
</section>

<section class="section-wrap section-wrap--tight hiring-page-wrap">
    <div class="panel hiring-gate">
        <p class="hiring-gate-eyebrow">Founder System</p>
        <h2>Draft clearer job posts before you hire</h2>
        <p>Use the hiring workflow to define the role, must-have skills, work type, location, expectations, and the kind of person who will succeed in the position.</p>
        <div class="hiring-preview-grid">
            <article>
                <h3>Role clarity</h3>
                <p>Turn a loose hiring need into a role title, responsibilities, and basic qualifications.</p>
            </article>
            <article>
                <h3>Better screening</h3>
                <p>Name the skills and traits that matter before interviews begin.</p>
            </article>
            <article>
                <h3>Ready to post</h3>
                <p>Create cleaner job listing language for your website, job board, or email outreach.</p>
            </article>
        </div>
        <div class="hero-cta-row">
            <a href="<?php echo esc_url(home_url('/register/')); ?>" class="btn-primary-lg">Register free</a>
            <a href="<?php echo esc_url(home_url('/pricing/')); ?>" class="btn-outline-lg">Price</a>
        </div>
    </div>
</section>

<?php get_footer(); ?>

