<?php
/**
 * Template Name: Login
 */

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['knoukno_login_nonce'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['knoukno_login_nonce'])), 'knoukno_login')) {
        $login_error = __('Security check failed. Please try again.', 'knoukno');
    } else {
        $identifier = isset($_POST['log']) ? sanitize_text_field(wp_unslash($_POST['log'])) : '';
        $password = isset($_POST['pwd']) ? (string) wp_unslash($_POST['pwd']) : '';
        $remember = isset($_POST['rememberme']);

        if ($identifier === '' || $password === '') {
            $login_error = __('Enter your email or username and password.', 'knoukno');
        } else {
            $user = is_email($identifier) ? get_user_by('email', $identifier) : get_user_by('login', $identifier);
            $credentials = [
                'user_login' => $user ? $user->user_login : $identifier,
                'user_password' => $password,
                'remember' => $remember,
            ];
            $signed_in = wp_signon($credentials, is_ssl());

            if (is_wp_error($signed_in)) {
                $login_error = __('Login failed. Check your details and try again.', 'knoukno');
            } else {
                wp_safe_redirect(home_url('/dashboard/'));
                exit;
            }
        }
    }
}

get_header();
?>

<section class="page-section content-page auth-bridge-page">
    <article class="panel auth-bridge-card auth-form-card">
        <p class="section-eyebrow">Account Access</p>
        <h1>Login</h1>
        <?php if (is_user_logged_in()) : ?>
            <p>You are logged in.</p>
            <div class="hero-cta-row">
                <a href="<?php echo esc_url(home_url('/dashboard/')); ?>" class="btn-primary-lg">Go to dashboard</a>
                <a href="<?php echo esc_url(wp_logout_url(home_url('/login/'))); ?>" class="btn-outline-lg">Logout</a>
            </div>
        <?php else : ?>
            <p>Use your local Kno U Kno WordPress preview account.</p>
            <?php if ($login_error) : ?>
                <p class="status-banner error"><?php echo esc_html($login_error); ?></p>
            <?php endif; ?>
            <form class="auth-form" method="post" action="<?php echo esc_url(home_url('/login/')); ?>">
                <?php wp_nonce_field('knoukno_login', 'knoukno_login_nonce'); ?>
                <div class="form-field">
                    <label for="knoukno-login">Email or username</label>
                    <input id="knoukno-login" name="log" type="text" autocomplete="username" required>
                </div>
                <div class="form-field">
                    <label for="knoukno-password">Password</label>
                    <div class="password-control">
                        <input id="knoukno-password" name="pwd" type="password" autocomplete="current-password" required>
                        <button class="password-toggle" type="button" data-password-toggle="knoukno-password" aria-label="Show password" aria-pressed="false">
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <path d="M2.25 12s3.5-6.25 9.75-6.25S21.75 12 21.75 12 18.25 18.25 12 18.25 2.25 12 2.25 12Z" />
                                <circle cx="12" cy="12" r="2.75" />
                            </svg>
                        </button>
                    </div>
                </div>
                <label class="checkbox-row">
                    <input name="rememberme" type="checkbox" value="forever">
                    Remember me
                </label>
                <button type="button" class="demo-login-fill" data-demo-login-fill data-demo-email="agstew1@gmail.com" data-demo-password="KnoUKno123!">Use demo account</button>
                <button type="submit" class="btn-primary-lg auth-submit">Login</button>
            </form>
            <p class="auth-switch">No account yet? <a href="<?php echo esc_url(home_url('/register/')); ?>">Register</a> | <a href="<?php echo esc_url(home_url('/forgot-password/')); ?>">Forgot password?</a></p>
        <?php endif; ?>
    </article>
</section>

<?php get_footer(); ?>
