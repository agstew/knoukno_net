<?php
/**
 * Kno U Kno theme functions.
 */

if (!defined('ABSPATH')) {
    exit;
}

function knoukno_setup(): void
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);

    register_nav_menus([
        'primary' => __('Primary Menu', 'knoukno'),
        'footer_platform' => __('Footer Platform Menu', 'knoukno'),
        'footer_workspace' => __('Footer Workspace Menu', 'knoukno'),
        'footer_founder' => __('Footer Founder System Menu', 'knoukno'),
    ]);
}
add_action('after_setup_theme', 'knoukno_setup');

function knoukno_assets(): void
{
    $theme_version = wp_get_theme()->get('Version');
    $theme_dir = get_template_directory();

    wp_enqueue_style('knoukno-style', get_stylesheet_uri(), [], filemtime($theme_dir . '/style.css') ?: $theme_version);
    wp_enqueue_script('knoukno-navigation', get_template_directory_uri() . '/assets/js/navigation.js', [], filemtime($theme_dir . '/assets/js/navigation.js') ?: $theme_version, true);
    wp_localize_script('knoukno-navigation', 'knouknoWorkspace', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('knoukno_workspace'),
        'isLoggedIn' => is_user_logged_in(),
    ]);
    wp_enqueue_script('knoukno-cookie-banner', get_template_directory_uri() . '/assets/js/cookie-banner.js', [], filemtime($theme_dir . '/assets/js/cookie-banner.js') ?: $theme_version, true);
}
add_action('wp_enqueue_scripts', 'knoukno_assets');

function knoukno_redirect_empty_query_string(): void
{
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';

    if ($request_uri === '' || !str_ends_with($request_uri, '?')) {
        return;
    }

    wp_safe_redirect(home_url(rtrim($request_uri, '?')), 301);
    exit;
}
add_action('template_redirect', 'knoukno_redirect_empty_query_string', 0);

function knoukno_app_url(string $path = ''): string
{
    return esc_url(home_url('/' . ltrim($path, '/')));
}

function knoukno_asset_url(string $path): string
{
    return esc_url(get_template_directory_uri() . '/assets/' . ltrim($path, '/'));
}

function knoukno_default_nav(): void
{
    $items = [
        ['Home', home_url('/')],
        ['About', home_url('/about/')],
        ['Price', home_url('/pricing/')],
        ['Login', home_url('/login/'), 'main-nav-link-cta'],
        ['Register', home_url('/register/'), 'main-nav-btn'],
    ];

    foreach ($items as $item) {
        [$label, $url, $class] = array_pad($item, 3, '');
        printf('<a class="%3$s" href="%2$s">%1$s</a>', esc_html($label), esc_url($url), esc_attr($class));
    }
}

function knoukno_footer_menu(string $location, array $fallback_links): void
{
    if (has_nav_menu($location)) {
        wp_nav_menu([
            'theme_location' => $location,
            'container' => false,
            'depth' => 1,
            'fallback_cb' => false,
        ]);
        return;
    }

    echo '<ul>';
    foreach ($fallback_links as $link) {
        printf('<li><a href="%2$s">%1$s</a></li>', esc_html($link['label']), esc_url($link['url']));
    }
    echo '</ul>';
}

function knoukno_workspace_pages(): array
{
    return [
        'about' => ['About', 'page-about.php'],
        'forgot-password' => ['Forgot Password', 'page-forgot-password.php'],
        'dashboard' => ['Dashboard', 'page-dashboard.php'],
        'title' => ['Title', 'page-workspace.php'],
        'questions' => ['Questions', 'page-workspace.php'],
        'grade' => ['Grade', 'page-workspace.php'],
        'rate' => ['Rate', 'page-workspace.php'],
        'average' => ['Average', 'page-workspace.php'],
    ];
}

function knoukno_workspace_nav(string $active_slug = ''): void
{
    $links = [
        'title' => 'Title',
        'questions' => 'Questions',
        'grade' => 'Grade',
        'rate' => 'Rate',
        'average' => 'Average',
    ];

    echo '<nav class="workspace-nav" aria-label="Workspace pages">';
    foreach ($links as $slug => $label) {
        $href = home_url('/' . $slug . '/');

        if ($slug === $active_slug) {
            printf('<a class="workspace-nav-link is-active" href="%2$s" aria-current="page">%1$s</a>', esc_html($label), esc_url($href));
            continue;
        }

        printf('<a class="workspace-nav-link" href="%2$s">%1$s</a>', esc_html($label), esc_url($href));
    }
    echo '</nav>';
}

function knoukno_ensure_workspace_pages(): void
{
    foreach (knoukno_workspace_pages() as $slug => $page_data) {
        [$title, $template] = $page_data;
        $existing_page = get_page_by_path($slug);

        if ($existing_page) {
            update_post_meta($existing_page->ID, '_wp_page_template', $template);
            continue;
        }

        $page_id = wp_insert_post([
            'post_title' => __($title, 'knoukno'),
            'post_name' => $slug,
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => '',
        ]);

        if (!is_wp_error($page_id)) {
            update_post_meta($page_id, '_wp_page_template', $template);
        }
    }
}
add_action('after_switch_theme', 'knoukno_ensure_workspace_pages');
add_action('init', 'knoukno_ensure_workspace_pages');

function knoukno_default_workspace_data(): array
{
    return [
        'title' => '',
        'answers' => [],
        'rates' => [],
        'grade' => 0,
        'rateAverage' => 0,
        'average' => 0,
        'updatedAt' => '',
    ];
}

function knoukno_normalize_workspace_data(array $data): array
{
    $answers = array_values(array_map('sanitize_textarea_field', array_slice($data['answers'] ?? [], 0, 175)));
    $rates = array_values(array_map(static function ($rate): string {
        return (string) max(0, min(5, (int) $rate));
    }, array_slice($data['rates'] ?? [], 0, 175)));

    $answered = count(array_filter($answers, static fn ($answer): bool => trim((string) $answer) !== ''));
    $question_count = max(count($answers), 5);
    $grade = (int) round(($answered / $question_count) * 100);
    $rate_total = array_reduce($rates, static fn ($total, $rate): int => $total + (int) $rate, 0);
    $rate_average = count($rates) > 0 ? $rate_total / count($rates) : 0;
    $average = (int) round(($grade + ($rate_average / 5) * 100) / 2);

    return [
        'title' => sanitize_text_field($data['title'] ?? ''),
        'answers' => $answers,
        'rates' => $rates,
        'grade' => $grade,
        'rateAverage' => round($rate_average, 1),
        'average' => $average,
        'updatedAt' => current_time('mysql'),
    ];
}

function knoukno_get_workspace_data(int $user_id): array
{
    $stored = get_user_meta($user_id, 'knoukno_workspace', true);

    if (!is_array($stored)) {
        return knoukno_default_workspace_data();
    }

    return array_merge(knoukno_default_workspace_data(), $stored);
}

function knoukno_get_business_titles(int $user_id): array
{
    $stored = get_user_meta($user_id, 'knoukno_business_titles', true);

    if (!is_array($stored)) {
        return [];
    }

    return array_values(array_filter(array_map(static function ($item): array {
        if (is_string($item)) {
            return ['title' => sanitize_text_field($item), 'updatedAt' => ''];
        }

        if (!is_array($item)) {
            return ['title' => '', 'updatedAt' => ''];
        }

        return [
            'title' => sanitize_text_field($item['title'] ?? ''),
            'updatedAt' => sanitize_text_field($item['updatedAt'] ?? ''),
        ];
    }, $stored), static fn ($item): bool => $item['title'] !== ''));
}

function knoukno_save_business_title(int $user_id, string $title): array
{
    $title = sanitize_text_field($title);

    if ($title === '') {
        return knoukno_get_business_titles($user_id);
    }

    $titles = array_values(array_filter(knoukno_get_business_titles($user_id), static fn ($item): bool => strcasecmp($item['title'], $title) !== 0));
    array_unshift($titles, ['title' => $title, 'updatedAt' => current_time('mysql')]);
    $titles = array_slice($titles, 0, 25);

    update_user_meta($user_id, 'knoukno_business_titles', $titles);

    return $titles;
}

function knoukno_ajax_load_workspace(): void
{
    check_ajax_referer('knoukno_workspace', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Login required.', 'knoukno')], 401);
    }

    wp_send_json_success(knoukno_get_workspace_data(get_current_user_id()));
}
add_action('wp_ajax_knoukno_load_workspace', 'knoukno_ajax_load_workspace');

function knoukno_ajax_save_workspace(): void
{
    check_ajax_referer('knoukno_workspace', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Login required.', 'knoukno')], 401);
    }

    $raw_payload = isset($_POST['workspace']) ? wp_unslash($_POST['workspace']) : '';
    $payload = json_decode((string) $raw_payload, true);

    if (!is_array($payload)) {
        wp_send_json_error(['message' => __('Invalid workspace data.', 'knoukno')], 400);
    }

    $workspace = knoukno_normalize_workspace_data($payload);
    update_user_meta(get_current_user_id(), 'knoukno_workspace', $workspace);

    if ($workspace['title'] !== '') {
        $workspace['businessTitles'] = knoukno_save_business_title(get_current_user_id(), $workspace['title']);
    }

    wp_send_json_success($workspace);
}
add_action('wp_ajax_knoukno_save_workspace', 'knoukno_ajax_save_workspace');
