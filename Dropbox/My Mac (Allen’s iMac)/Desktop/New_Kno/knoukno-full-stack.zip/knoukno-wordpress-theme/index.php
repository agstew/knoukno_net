<?php
/**
 * Default template.
 */
get_header();
?>

<section class="page-section content-page">
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h1><?php the_title(); ?></h1>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </article>
        <?php endwhile; ?>
    <?php else : ?>
        <article class="panel">
            <h1><?php esc_html_e('Page not found', 'knoukno'); ?></h1>
            <p><?php esc_html_e('The page you requested could not be found.', 'knoukno'); ?></p>
        </article>
    <?php endif; ?>
</section>

<?php get_footer(); ?>
