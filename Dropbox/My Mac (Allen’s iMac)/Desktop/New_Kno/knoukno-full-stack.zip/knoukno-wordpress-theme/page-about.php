<?php
/**
 * Template Name: About
 */
get_header();

$about_paragraphs = [
    'KnoUKno.net is built for people who have a business idea, a service, a product, or a plan that needs structure before it can grow. The site begins with registration because every serious business plan needs an owner, a saved workspace, and a place where progress can return. After a client registers, Kno U Kno gives that client a dashboard, a business title list, questions, answer text areas, save controls, print controls, grade tools, rating tools, and average results. The goal is simple: help the user move from a loose idea to a written plan that can be reviewed, improved, and used.',
    'The platform uses AI-style guidance to ask focused business questions, but it does not try to replace the founder. A good founder still has to decide what the company is called, who the customer is, what problem is being solved, what service or product will be sold first, where customers will find the business, and what action should happen next. Kno U Kno gives those decisions a place to land. Instead of keeping business notes in scattered documents, messages, or notebooks, the client writes inside one guided workspace connected to a business title.',
    'Free users can begin with five questions for three days. That first tier is intentionally small because it helps a new user test the system without confusion. The free workspace is designed for the first business title, the first five answers, saving, printing, and seeing how the page works. Member users can expand to fifty questions each month. Pro users can expand to seventy-five questions each year. Bonus tiers add deeper question sets for users who want more planning room, including one hundred fifty questions for Member-Bonus and one hundred seventy-five questions for Pro-Bonus.',
    'The question system is organized for practical business thinking. Questions can cover the business title, customer type, first offer, location, online presence, hiring needs, law and registration concerns, pricing, operations, sales, follow-up, and customer growth. Examples sit beside questions so the user can see what a stronger answer may look like. The examples are different across the larger question bank, which helps the page feel useful instead of repetitive. The answer area keeps the client focused on writing one response at a time.',
    'Kno U Kno also separates important actions into clear sections. Title helps the user name and select a business. Questions gives the user the prompt and answer area. Grade measures completion. Rated lets a user score answer quality. Average combines progress into a simple result. Print turns the page into a document. Save keeps the work available. Delete is available in the admin system when a title or saved record needs to be removed. These controls are direct because the platform is meant for repeated work, not decoration.',
    'The admin dashboard is connected to MongoDB so records can be collected for titles, payments, login events, registration events, prints, saves, questions, grades, ratings, answers, averages, deletes, email records, examples, and email letters. That structure gives the project room to grow beyond a simple page. A title can be created, shown in a list, clicked by name, and opened on the questions page. The admin side also includes sections for print, save, question, grade, rated, answers, average, delete, save answers, save grade, save rated, average save, save all, and email.',
    'The public website keeps the visual language clear: dodgerblue for primary action, gold for value and highlights, white for space, and black for contrast. The homepage introduces the AI business planning idea with cards, images, and direct calls to register. The Price page explains the Free, Member, Pro, Member-Bonus, and Pro-Bonus tiers. Login and Register keep access simple. About explains why the system exists. Every public path points toward registration because the real product is the saved client workspace.',
    'Kno U Kno is not only a question page. It is a planning rhythm. A client names the business, opens the list, clicks the title, answers the next question, saves the work, prints when needed, grades completion, rates quality, reviews the average, and comes back again. That rhythm can help a founder see what is still weak, what is already clear, and what should happen next. The website is made to support that steady progress from idea to action.',
    'The long-term direction is to make the workspace useful for both the client and the admin. Clients need a calm place to write and return to their answers. Admin users need a clear place to see titles, lists, questions, examples, answers, grades, ratings, averages, payments, emails, and saved activity. When those two sides work together, Kno U Kno can become a practical operating record for early business planning, client follow-up, and stronger decision making.',
];

$about_cards = [
    ['title' => 'Registered First', 'text' => 'Every client starts with an account so titles, answers, scores, and saved work stay connected.', 'image' => 'img/people-real-1.jpg', 'alt' => 'Registered client planning a business'],
    ['title' => 'Questions With Examples', 'text' => 'The question bank and AI-written examples help each founder write clearer answers.', 'image' => 'img/people-real-2.jpg', 'alt' => 'Client answering business questions'],
    ['title' => 'Save, Print, Improve', 'text' => 'The dashboard supports save, print, grade, rated, answers, average, and delete workflows.', 'image' => 'img/people-founders-3.svg', 'alt' => 'Dashboard workflow illustration'],
];
?>

<section class="page-section content-page about-page">
    <div class="dashboard-header panel about-hero-card">
        <div>
            <p class="section-eyebrow">About</p>
            <h1>About KnoUKno.net</h1>
            <p>AI business planning for registered clients who need titles, questions, answers, grades, ratings, averages, saves, prints, and clear next steps.</p>
        </div>
        <div class="hero-cta-row">
            <a href="<?php echo esc_url(home_url('/register/')); ?>" class="btn-primary-lg">Register</a>
            <a href="<?php echo esc_url(home_url('/pricing/')); ?>" class="btn-outline-lg">Price</a>
        </div>
    </div>

    <div class="about-grid">
        <?php foreach ($about_cards as $card) : ?>
            <article class="panel about-feature-card">
                <img src="<?php echo knoukno_asset_url($card['image']); ?>" alt="<?php echo esc_attr($card['alt']); ?>">
                <h2><?php echo esc_html($card['title']); ?></h2>
                <p><?php echo esc_html($card['text']); ?></p>
            </article>
        <?php endforeach; ?>
    </div>

    <article class="panel about-copy-card">
        <?php foreach ($about_paragraphs as $paragraph) : ?>
            <p><?php echo esc_html($paragraph); ?></p>
        <?php endforeach; ?>
    </article>
</section>

<?php get_footer(); ?>