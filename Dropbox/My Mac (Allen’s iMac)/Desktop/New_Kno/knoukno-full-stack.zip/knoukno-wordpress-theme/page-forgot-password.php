<?php
/**
 * Template Name: Forgot Password
 */

$reset_error = '';
$reset_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['knoukno_forgot_password_nonce'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['knoukno_forgot_password_nonce'])), 'knoukno_forgot_password')) {
        $reset_error = __('Security check failed. Please try again.', 'knoukno');
    } else {
        $identifier = isset($_POST['user_login']) ? sanitize_text_field(wp_unslash($_POST['user_login'])) : '';

        if ($identifier === '') {
            $reset_error = __('Enter your email or username.', 'knoukno');
        } else {
            $_POST['user_login'] = $identifier;
            $reset_result = retrieve_password();

            if (is_wp_error($reset_result)) {
                $reset_error = $reset_result->get_error_message();
            } else {
                $reset_success = __('Password reset instructions were sent if the account exists.', 'knoukno');
            }
        }
    }
}

get_header();
?>

<section class="page-section content-page auth-bridge-page">
    <article class="panel auth-bridge-card auth-form-card">
        <p class="section-eyebrow">Account Help</p>
        <h1>Forgot Password</h1>
        <p>Enter the email or username for your Kno U Kno account.</p>
        <?php if ($reset_error) : ?>
            <p class="status-banner error"><?php echo wp_kses_post($reset_error); ?></p>
        <?php endif; ?>
        <?php if ($reset_success) : ?>
            <p class="status-banner success"><?php echo esc_html($reset_success); ?></p>
        <?php endif; ?>
        <form class="auth-form" method="post" action="<?php echo esc_url(home_url('/forgot-password/')); ?>">
            <?php wp_nonce_field('knoukno_forgot_password', 'knoukno_forgot_password_nonce'); ?>
            <div class="form-field">
                <label for="knoukno-reset-login">Email or username</label>
                <input id="knoukno-reset-login" name="user_login" type="text" autocomplete="username" required>
            </div>
            <button type="submit" class="btn-primary-lg auth-submit">Send reset link</button>
        </form>
        <p class="auth-switch"><a href="<?php echo esc_url(home_url('/login/')); ?>">Back to Login</a> or <a href="<?php echo esc_url(home_url('/register/')); ?>">Register</a></p>
    </article>
</section>

<?php get_footer(); ?>