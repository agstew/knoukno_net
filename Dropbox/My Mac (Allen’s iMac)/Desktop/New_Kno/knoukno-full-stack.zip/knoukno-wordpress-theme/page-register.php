<?php
/**
 * Template Name: Register
 */

$register_error = '';

if (!function_exists('knoukno_unique_username_from_email')) {
    function knoukno_unique_username_from_email(string $email): string
    {
        $base = sanitize_user(strstr($email, '@', true) ?: $email, true);
        $base = $base !== '' ? $base : 'knoukno_user';
        $username = $base;
        $suffix = 1;

        while (username_exists($username)) {
            $username = $base . $suffix;
            $suffix++;
        }

        return $username;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['knoukno_register_nonce'])) {
    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['knoukno_register_nonce'])), 'knoukno_register')) {
        $register_error = __('Security check failed. Please try again.', 'knoukno');
    } else {
        $full_name = isset($_POST['full_name']) ? sanitize_text_field(wp_unslash($_POST['full_name'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $password = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';
        $confirm_password = isset($_POST['confirm_password']) ? (string) wp_unslash($_POST['confirm_password']) : '';

        if ($full_name === '' || $email === '' || $password === '') {
            $register_error = __('Name, email, and password are required.', 'knoukno');
        } elseif (!is_email($email)) {
            $register_error = __('Enter a valid email address.', 'knoukno');
        } elseif (email_exists($email)) {
            $register_error = __('That email already has an account. Please login.', 'knoukno');
        } elseif (strlen($password) < 8) {
            $register_error = __('Use at least 8 characters for your password.', 'knoukno');
        } elseif ($password !== $confirm_password) {
            $register_error = __('Passwords do not match.', 'knoukno');
        } else {
            $username = knoukno_unique_username_from_email($email);
            $user_id = wp_create_user($username, $password, $email);

            if (is_wp_error($user_id)) {
                $register_error = $user_id->get_error_message();
            } else {
                wp_update_user([
                    'ID' => $user_id,
                    'display_name' => $full_name,
                    'first_name' => $full_name,
                ]);
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id, true, is_ssl());
                wp_safe_redirect(home_url('/dashboard/'));
                exit;
            }
        }
    }
}

get_header();
?>

<section class="page-section content-page auth-bridge-page">
    <article class="panel auth-bridge-card auth-form-card">
        <p class="section-eyebrow">Start Free</p>
        <h1>Register</h1>
        <?php if (is_user_logged_in()) : ?>
            <p>You already have a local preview account session.</p>
            <div class="hero-cta-row">
                <a href="<?php echo esc_url(home_url('/dashboard/')); ?>" class="btn-primary-lg">Go to dashboard</a>
                <a href="<?php echo esc_url(wp_logout_url(home_url('/register/'))); ?>" class="btn-outline-lg">Logout</a>
            </div>
        <?php else : ?>
            <p>Create a local WordPress preview account for this site.</p>
            <?php if ($register_error) : ?>
                <p class="status-banner error"><?php echo esc_html($register_error); ?></p>
            <?php endif; ?>
            <form class="auth-form" method="post" action="<?php echo esc_url(home_url('/register/')); ?>">
                <?php wp_nonce_field('knoukno_register', 'knoukno_register_nonce'); ?>
                <div class="form-field">
                    <label for="knoukno-name">Name</label>
                    <input id="knoukno-name" name="full_name" type="text" autocomplete="name" required>
                </div>
                <div class="form-field">
                    <label for="knoukno-email">Email</label>
                    <input id="knoukno-email" name="email" type="email" autocomplete="email" required>
                </div>
                <div class="form-field">
                    <label for="knoukno-register-password">Password</label>
                    <div class="password-control">
                        <input id="knoukno-register-password" name="password" type="password" autocomplete="new-password" minlength="8" required>
                        <button class="password-toggle" type="button" data-password-toggle="knoukno-register-password" aria-label="Show password" aria-pressed="false">
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <path d="M2.25 12s3.5-6.25 9.75-6.25S21.75 12 21.75 12 18.25 18.25 12 18.25 2.25 12 2.25 12Z" />
                                <circle cx="12" cy="12" r="2.75" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="form-field">
                    <label for="knoukno-confirm-password">Confirm password</label>
                    <div class="password-control">
                        <input id="knoukno-confirm-password" name="confirm_password" type="password" autocomplete="new-password" minlength="8" required>
                        <button class="password-toggle" type="button" data-password-toggle="knoukno-confirm-password" aria-label="Show password" aria-pressed="false">
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <path d="M2.25 12s3.5-6.25 9.75-6.25S21.75 12 21.75 12 18.25 18.25 12 18.25 2.25 12 2.25 12Z" />
                                <circle cx="12" cy="12" r="2.75" />
                            </svg>
                        </button>
                    </div>
                </div>
                <button type="submit" class="btn-primary-lg auth-submit">Create account</button>
            </form>
            <p class="auth-switch">Already registered? <a href="<?php echo esc_url(home_url('/login/')); ?>">Login</a></p>
        <?php endif; ?>
    </article>
</section>

<?php get_footer(); ?>
