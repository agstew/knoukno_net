# Kno U Kno WordPress Theme

This folder is a WordPress theme for the KnoUKno.net AI business planning website. It includes:

- Home page with AI business planning copy, cards, and images.
- Price page with Free, Member, Pro, Member-Bonus, and Pro-Bonus tiers.
- Login and Register pages using WordPress users.
- Registered dashboard with business title, 5 questions, answer text areas, save, print, grade, rate, and average controls.

## Install

1. Zip the `knoukno-wordpress-theme` folder or use the generated `knoukno-wordpress-theme.zip` package.
2. In WordPress admin, go to Appearance > Themes > Add New > Upload Theme.
3. Upload the zip and activate **Kno U Kno**.
4. Create pages with slugs `pricing`, `login`, `register`, `checkout`, and `dashboard`, assigning the matching templates.
5. Set the home page under Settings > Reading if WordPress does not automatically use the theme front page.

## Local Preview

In this workspace, the local preview runs at `http://localhost:8080/`. The navigation is Home, Price, Login, Register.
