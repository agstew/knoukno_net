<?php
/**
 * Template Name: Checkout
 *
 * Local checkout bridge page while the app subdomain is being configured.
 */
get_header();

$tier_labels = [
    'FREE' => 'Free Tier',
    'MEMBER' => 'Tier Member 1',
    'PRO' => 'Tier Pro 1',
    'MEMBER_BONUS' => 'Tier Member-Bonus 1',
    'PRO_BONUS' => 'Tier Pro-Bonus 1',
];
$selected_tier = isset($_GET['tier']) ? sanitize_key(wp_unslash($_GET['tier'])) : '';
$selected_tier = strtoupper($selected_tier);
$tier_label = $tier_labels[$selected_tier] ?? 'Selected tier';
?>

<section class="page-section content-page auth-bridge-page">
    <article class="panel auth-bridge-card">
        <p class="section-eyebrow">Checkout</p>
        <h1><?php echo esc_html($tier_label); ?></h1>
        <p>This local WordPress preview keeps the selected tier visible and ready for payment setup.</p>
        <?php if ($selected_tier) : ?>
            <p class="result-callout">Tier code: <?php echo esc_html($selected_tier); ?></p>
        <?php endif; ?>
        <div class="hero-cta-row">
            <a href="<?php echo esc_url(home_url('/pricing/')); ?>" class="btn-primary-lg">Back to Price</a>
            <a href="<?php echo esc_url(home_url('/register/')); ?>" class="btn-outline-lg">Register</a>
        </div>
    </article>
</section>

<?php get_footer(); ?>
