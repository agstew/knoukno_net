<?php
/**
 * Template Name: Workspace Page
 */

if (!is_user_logged_in()) {
    wp_safe_redirect(home_url('/login/'));
    exit;
}

$current_user = wp_get_current_user();
$page_slug = get_post_field('post_name', get_queried_object_id()) ?: 'title';
$page_title = ucfirst($page_slug);
$business_titles = knoukno_get_business_titles($current_user->ID);
$selected_business = isset($_GET['business']) ? sanitize_text_field(wp_unslash($_GET['business'])) : '';
$questions = [
    'What is the title of your business and what problem does it solve?',
    'Who is your best customer and why will that person choose you?',
    'What product or service are you selling first?',
    'Where will customers find you: location, website, social, referral, or all of them?',
    'What is the next action you must finish in the next 3 days?',
];
$examples = [
    'Kno U Kno helps new founders turn a loose business idea into a saved plan with questions, answers, grades, ratings, and next steps.',
    'My best customer is a first-time business owner who needs clear prompts before spending money on tools, ads, or hiring.',
    'The first service is a guided setup session that creates the business title, customer notes, first offer, and action list.',
    'Customers can find the business on the website first, then through referrals, local outreach, and follow-up emails.',
    'The next action is to finish the five starter answers, save the page, print it, and choose whether to upgrade.',
];

get_header();
?>

<section class="page-section content-page dashboard-page client-workspace workspace-page workspace-page--<?php echo esc_attr($page_slug); ?>" data-client-workspace data-workspace-user="<?php echo esc_attr($current_user->ID); ?>">
    <?php if ($page_slug !== 'title') : ?>
        <div class="dashboard-header panel">
            <div>
                <p class="section-eyebrow">Workspace</p>
                <h1><?php echo esc_html($page_title); ?></h1>
            </div>
            <div class="hero-cta-row">
                <a href="<?php echo esc_url(home_url('/dashboard/')); ?>" class="btn-primary-lg">Dashboard</a>
                <a href="<?php echo esc_url(wp_logout_url(home_url('/login/'))); ?>" class="btn-outline-lg">Logout</a>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($page_slug !== 'title') : ?>
        <?php knoukno_workspace_nav($page_slug); ?>
    <?php endif; ?>

    <?php if ($page_slug === 'title') : ?>
        <article class="panel workspace-focus-card">
            <div class="business-list-block">
                <h2>Business Title List</h2>
                <p>Click a business title to open the questions page for that business.</p>
                <ul class="business-list" data-business-list>
                    <?php if ($business_titles) : ?>
                        <?php foreach ($business_titles as $business_title) : ?>
                            <?php $questions_url = add_query_arg('business', rawurlencode($business_title['title']), home_url('/questions/')); ?>
                            <li class="business-list-row" data-business-href="<?php echo esc_url($questions_url); ?>" tabindex="0">
                                <a class="business-title-link" href="<?php echo esc_url($questions_url); ?>"><?php echo esc_html($business_title['title']); ?></a>
                                <a href="<?php echo esc_url($questions_url); ?>">Questions</a>
                            </li>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <li data-empty-business-list>No businesses saved yet.</li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="dashboard-header workspace-title-header">
                <div>
                    <p class="section-eyebrow">Workspace</p>
                    <h1>Title</h1>
                </div>
                <div class="hero-cta-row">
                    <a href="<?php echo esc_url(home_url('/dashboard/')); ?>" class="btn-primary-lg">Dashboard</a>
                    <a href="<?php echo esc_url(wp_logout_url(home_url('/login/'))); ?>" class="btn-outline-lg">Logout</a>
                </div>
            </div>
            <h2>Business Title</h2>
            <p>Write your business title, then click Save Title to put it in the Business Title List.</p>
            <div class="form-field business-title-field">
                <label for="business-title">Business Title</label>
                <div class="business-title-control">
                    <input id="business-title" name="business-title" type="text" placeholder="Example: KnoUKno AI Planning" data-business-title>
                    <button type="button" class="btn-primary-lg" data-save-title>Save Title</button>
                </div>
            </div>
            <p class="workspace-status" data-workspace-status>After saving, click the business title in the list to open Questions.</p>
        </article>
        <?php knoukno_workspace_nav($page_slug); ?>
    <?php elseif ($page_slug === 'questions') : ?>
        <form class="question-workspace panel" data-question-form>
            <div class="question-workspace-head">
                <div>
                    <p class="section-eyebrow">Questions</p>
                    <h2>Pagination: 1 - 5 Questions</h2>
                </div>
                <p>Write 5 answers in the text areas, then save or print the page.</p>
            </div>
            <?php if ($selected_business !== '') : ?>
                <p class="selected-business-notice"><span>Selected business</span><strong><?php echo esc_html($selected_business); ?></strong></p>
            <?php endif; ?>
            <?php foreach ($questions as $index => $question) : ?>
                <article class="question-card" data-question-card>
                    <div class="question-card-head">
                        <span><?php echo esc_html((string) ($index + 1)); ?></span>
                        <div>
                            <p class="question-meta-label">Question</p>
                            <h3><?php echo esc_html($question); ?></h3>
                        </div>
                    </div>
                    <p class="question-example"><span>Example</span><?php echo esc_html($examples[$index]); ?></p>
                    <label class="answer-label" for="workspace-answer-<?php echo esc_attr((string) ($index + 1)); ?>">Answers</label>
                    <textarea id="workspace-answer-<?php echo esc_attr((string) ($index + 1)); ?>" rows="5" placeholder="Write answer <?php echo esc_attr((string) ($index + 1)); ?> here" data-answer></textarea>
                </article>
            <?php endforeach; ?>
            <div class="workspace-actions">
                <button type="button" class="btn-primary-lg" data-save-workspace>Save Page</button>
                <button type="button" class="btn-outline-lg" data-print-workspace>Print Page</button>
            </div>
            <p class="workspace-status" data-workspace-status>Saved answers go into the WordPress database.</p>
        </form>
    <?php elseif ($page_slug === 'grade') : ?>
        <article class="panel workspace-focus-card">
            <p class="section-eyebrow">Grade</p>
            <h2>Grade Page</h2>
            <div class="client-scoreboard client-scoreboard--single" aria-live="polite">
                <p><span>Grade Page</span><strong data-grade-output>F = 0</strong></p>
            </div>
            <p>Grade is based on completed answers: A = 4, B = 3, C = 2, D = 1, F = 0.</p>
            <div class="workspace-actions">
                <button type="button" class="btn-primary-lg" data-grade-workspace>Grade Page</button>
                <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/questions/')); ?>">Questions</a>
            </div>
        </article>
    <?php elseif ($page_slug === 'rate') : ?>
        <form class="question-workspace panel">
            <div class="question-workspace-head">
                <div>
                    <p class="section-eyebrow">Rate</p>
                    <h2>Rate Page</h2>
                </div>
                <p>Rate each answer from 0 to 5.</p>
            </div>
            <?php foreach ($questions as $index => $question) : ?>
                <article class="question-card">
                    <div class="question-card-head">
                        <span><?php echo esc_html((string) ($index + 1)); ?></span>
                        <h3><?php echo esc_html($question); ?></h3>
                    </div>
                    <div class="rate-row">
                        <label for="workspace-rate-<?php echo esc_attr((string) ($index + 1)); ?>">Rate answer</label>
                        <select id="workspace-rate-<?php echo esc_attr((string) ($index + 1)); ?>" data-rate>
                            <?php for ($rating = 0; $rating <= 5; $rating++) : ?>
                                <option value="<?php echo esc_attr((string) $rating); ?>"><?php echo esc_html((string) $rating); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="client-scoreboard client-scoreboard--single" aria-live="polite">
                <p><span>Rate Page</span><strong data-rate-output>0.0 / 5</strong></p>
            </div>
            <div class="workspace-actions">
                <button type="button" class="btn-primary-lg" data-save-workspace>Save Page</button>
            </div>
            <p class="workspace-status" data-workspace-status>Saved rates go into the WordPress database.</p>
        </form>
    <?php else : ?>
        <article class="panel workspace-focus-card">
            <p class="section-eyebrow">Average</p>
            <h2>Average Page</h2>
            <div class="client-scoreboard" aria-live="polite">
                <p><span>Grade Page</span><strong data-grade-output>F = 0</strong></p>
                <p><span>Rate Page</span><strong data-rate-output>0.0 / 5</strong></p>
                <p><span>Average Page</span><strong data-average-output>0%</strong></p>
            </div>
            <p>The average combines completed answers and answer ratings.</p>
            <div class="workspace-actions">
                <a class="btn-primary-lg" href="<?php echo esc_url(home_url('/questions/')); ?>">Questions</a>
                <a class="btn-outline-lg" href="<?php echo esc_url(home_url('/rate/')); ?>">Rate</a>
                <button type="button" class="btn-outline-lg" data-print-workspace>Print Page</button>
            </div>
        </article>
    <?php endif; ?>
</section>

<?php get_footer(); ?>
