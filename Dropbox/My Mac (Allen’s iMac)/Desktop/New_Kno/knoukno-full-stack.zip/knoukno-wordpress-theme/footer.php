<?php
/**
 * Theme footer.
 */
$platform_links = [
    ['label' => 'Home', 'url' => home_url('/')],
    ['label' => 'About', 'url' => home_url('/about/')],
    ['label' => 'Price', 'url' => home_url('/pricing/')],
    ['label' => 'Login', 'url' => home_url('/login/')],
    ['label' => 'Register', 'url' => home_url('/register/')],
    ['label' => 'Forgot Password', 'url' => home_url('/forgot-password/')],
];
$workspace_links = [
    ['label' => 'Title', 'url' => home_url('/title/')],
    ['label' => 'Questions', 'url' => home_url('/questions/')],
    ['label' => 'Grade', 'url' => home_url('/grade/')],
    ['label' => 'Rate', 'url' => home_url('/rate/')],
    ['label' => 'Average', 'url' => home_url('/average/')],
];
$founder_links = [
    ['label' => 'Law', 'url' => home_url('/register/')],
    ['label' => 'Location', 'url' => home_url('/register/')],
    ['label' => 'Hiring', 'url' => home_url('/hiring/')],
    ['label' => 'Customer', 'url' => home_url('/register/')],
];
?>
    </main>
    <footer class="site-footer">
        <div class="site-footer-inner">
            <div class="site-footer-brand">
                <p class="site-footer-logo">Kno U Kno</p>
                <p class="site-footer-tag">AI business planning from law to location, hiring to customer growth with measurable execution.</p>
                <a class="btn-primary-lg site-footer-cta" href="<?php echo esc_url(home_url('/register/')); ?>">Start for free</a>
            </div>
            <div class="site-footer-columns">
                <div class="site-footer-col">
                    <p class="site-footer-heading">Platform</p>
                    <?php knoukno_footer_menu('footer_platform', $platform_links); ?>
                </div>
                <div class="site-footer-col">
                    <p class="site-footer-heading">Workspace</p>
                    <?php knoukno_footer_menu('footer_workspace', $workspace_links); ?>
                </div>
                <div class="site-footer-col">
                    <p class="site-footer-heading">Founder System</p>
                    <?php knoukno_footer_menu('footer_founder', $founder_links); ?>
                </div>
            </div>
        </div>
        <div class="site-footer-base">
            <p>&copy; Kno U Kno <?php echo esc_html(date_i18n('Y')); ?></p>
        </div>
    </footer>
    <aside class="cookie-banner" data-cookie-banner hidden>
        <div class="cookie-banner-inner">
            <p class="cookie-banner-text">Kno U Kno uses cookies to keep the site useful and improve the planning experience.</p>
            <div class="cookie-banner-actions">
                <button type="button" class="cookie-banner-btn cookie-banner-btn--no" data-cookie-dismiss>No thanks</button>
                <button type="button" class="cookie-banner-btn cookie-banner-btn--yes" data-cookie-accept>Accept</button>
            </div>
        </div>
    </aside>
</div>
<?php wp_footer(); ?>
</body>
</html>
