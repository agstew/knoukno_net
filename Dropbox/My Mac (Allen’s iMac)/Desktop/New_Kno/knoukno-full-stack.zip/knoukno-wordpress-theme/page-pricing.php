<?php
/**
 * Template Name: Pricing
 *
 * Price page for KnoUKno.net.
 */
get_header();

$tiers = [
    [
        'key' => 'FREE',
        'label' => 'Free Tier',
        'questions' => '5 questions',
        'term' => '3 days',
        'price' => '$0',
        'discount' => 'No bonus.',
        'features' => ['Title for the Business', 'Pagination: 1 - 5 Questions', '5 answer text areas', 'Save page', 'Print page'],
    ],
    [
        'key' => 'MEMBER',
        'label' => 'Tier Member 1',
        'questions' => '50 questions',
        'term' => 'Month',
        'price' => '$39.00',
        'was' => '$49.00',
        'discount' => 'Discount 20% gets $10.00 off.',
        'features' => ['Title for the Business', 'Pagination: 1 - 50 Questions', 'Print page', 'Save page', 'Grade page', 'Rate page', 'Average page'],
    ],
    [
        'key' => 'PRO',
        'label' => 'Tier Pro 1',
        'questions' => '75 questions',
        'term' => 'Year',
        'price' => '$436.00',
        'was' => '$675.00',
        'discount' => 'Discount 35% gets $235.00 off.',
        'features' => ['Title for the Business', 'Pagination: 1 - 75 Questions', 'Print page', 'Save page', 'Grade page', 'Rate page', 'Average page'],
    ],
    [
        'key' => 'MEMBER_BONUS',
        'label' => 'Tier Member-Bonus 1',
        'questions' => '150 questions',
        'term' => 'Member bonus',
        'price' => '$139.00',
        'discount' => 'Bonus: 150 questions for $100.00 if you buy now.',
        'features' => ['Everything in Member', '100 bonus questions', '150 total questions', 'Save, print, grade, rate, average'],
    ],
    [
        'key' => 'PRO_BONUS',
        'label' => 'Tier Pro-Bonus 1',
        'questions' => '175 questions',
        'term' => 'Pro bonus',
        'price' => '$536.00',
        'discount' => 'Bonus: 175 questions for $100.00 if you buy now.',
        'features' => ['Everything in Pro', '100 bonus questions', '175 total questions', 'Save, print, grade, rate, average'],
    ],
];
?>

<section class="price-section container ai-price-page">
    <p class="section-eyebrow">New Page</p>
    <h1>Price</h1>
    <div class="panel page-intro-card">
        <p>KnoUKno.net requires registration before the client workspace. Start free with 5 questions for 3 days, then choose Member, Pro, or a bonus question tier.</p>
    </div>
    <div class="tier-grid ai-tier-grid">
        <?php foreach ($tiers as $tier) : ?>
            <article class="panel tier-card ai-tier-card">
                <div>
                    <p class="tier-kicker"><?php echo esc_html($tier['term']); ?></p>
                    <h2><?php echo esc_html($tier['label']); ?></h2>
                </div>
                <p class="tier-question-count"><?php echo esc_html($tier['questions']); ?></p>
                <div class="tier-price-row">
                    <strong><?php echo esc_html($tier['price']); ?></strong>
                    <?php if (!empty($tier['was'])) : ?>
                        <span><?php echo esc_html($tier['was']); ?></span>
                    <?php endif; ?>
                </div>
                <p class="result-callout"><?php echo esc_html($tier['discount']); ?></p>
                <ul class="tier-feature-list">
                    <?php foreach ($tier['features'] as $feature) : ?>
                        <li><?php echo esc_html($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a class="btn-primary-lg" href="<?php echo esc_url(add_query_arg('tier', rawurlencode($tier['key']), home_url('/checkout/'))); ?>">Buy Now</a>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php get_footer(); ?>
