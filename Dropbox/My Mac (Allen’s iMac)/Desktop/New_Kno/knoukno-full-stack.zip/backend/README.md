# KnoUKno MongoDB Backend

Node/Express backend scaffold for the KnoUKno.net registered client workspace.

## Collections

- `payments` - tier purchases and payment links
- `titles` - business titles/workspaces
- `logins` - login event records
- `registrations` - registration event records
- `prints` - print events
- `saves` - save events
- `questions` - AI-generated business startup/forward questions
- `examples` - AI-generated example answers
- `grades` - grade snapshots
- `ratings` - per-question ratings
- `answers` - client-written answers
- `averages` - average snapshots
- `deletes` - delete audit events
- `emails` - registered email records
- `emailLetters` - 360 different client email letters

The model keeps growing user content like answers and ratings in separate collections to avoid unbounded arrays and 16MB document risks.

## Run

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Local `.env` values:

```bash
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB=knoukno
PORT=5050
CORS_ORIGIN=http://localhost:8080,http://localhost:5174
JWT_SECRET=change-this-to-a-long-random-secret
JWT_EXPIRES_IN=7d
```

Seed/create collections, 300 startup questions, 300 examples, and 360 client email letters:

```bash
curl -X POST http://localhost:5050/setup
```

The question API supports tier pagination:

- `FREE` gives questions 1 - 5
- `MEMBER` gives questions 1 - 50
- `PRO` gives questions 1 - 75
- `BONUS_100` gives questions 1 - 100
- `MEMBER_BONUS_150` gives questions 1 - 150
- `PRO_BONUS_175` gives questions 1 - 175

The API expects the logged-in user id in `x-knoukno-user-id` or `userId` until real auth middleware is connected.
