const foundations = [
  'legal setup',
  'license and permit planning',
  'customer problem',
  'first offer',
  'pricing logic',
  'startup budget',
  'location decision',
  'online channel',
  'supplier plan',
  'sales process',
  'service promise',
  'hiring priority',
  'training plan',
  'daily operations',
  'cash flow',
  'risk control',
  'marketing message',
  'customer retention',
  'growth milestone',
  'next action'
];

const prompts = [
  'What decision must you make about {topic} before the business opens?',
  'What information do you still need about {topic}, and where will you get it?',
  'What mistake could hurt {topic}, and how will you prevent it?',
  'What is the simplest first version of your {topic} plan?',
  'Who needs to approve, support, or understand your {topic} decision?',
  'What cost, time, or legal limit affects {topic}?',
  'How will you measure whether {topic} is working?',
  'What task should be finished this week for {topic}?',
  'What document, checklist, or proof do you need for {topic}?',
  'What would make your {topic} plan stronger before launch?',
  'How does {topic} affect the customer experience?',
  'What should you stop doing if {topic} is not working?',
  'What is your backup plan for {topic}?',
  'What question would a lender, partner, or landlord ask about {topic}?',
  'What answer would make your {topic} plan clear to another person?'
];

const exampleActions = [
  'call city hall and write down the permit office contact',
  'compare three local competitors and mark the clearest price',
  'ask five likely customers what they would buy first',
  'draft a one-page checklist before spending money',
  'book a meeting with a banker, landlord, mentor, or supplier',
  'set a starter budget and name the largest risk',
  'test one small offer with a real customer conversation',
  'choose the first sales channel and post one simple message',
  'save proof, screenshots, receipts, or notes in one folder',
  'write the next task on the calendar with an owner'
];

const exampleMetrics = [
  'one signed note',
  'three price checks',
  'five customer replies',
  'one completed checklist',
  'two appointment options',
  '$100 cost estimate',
  'one test sale attempt',
  'one public post',
  'one saved proof folder',
  'one calendar deadline'
];

const exampleDeadlines = [
  'before Friday',
  'within 24 hours',
  'by the end of the week',
  'before the next purchase',
  'within three business days',
  'before opening day',
  'by tomorrow morning',
  'before the next client call',
  'within seven days',
  'before the next dashboard review'
];

function buildQuestionExample(questionNumber, topic, prompt) {
  const action = exampleActions[(questionNumber - 1) % exampleActions.length];
  const metric = exampleMetrics[(questionNumber + 2) % exampleMetrics.length];
  const deadline = exampleDeadlines[(questionNumber + 4) % exampleDeadlines.length];
  const decisionNumber = String(questionNumber).padStart(3, '0');

  return `Example ${decisionNumber}: For ${topic}, answer "${prompt}" by choosing one real action: ${action}. The proof is ${metric}, and the deadline is ${deadline}.`;
}

export function buildBusinessQuestions(limit = 300) {
  const questions = [];
  const tierRanges = [
    ['FREE', 5],
    ['MEMBER', 50],
    ['PRO', 75],
    ['BONUS_100', 100],
    ['MEMBER_BONUS_150', 150],
    ['PRO_BONUS_175', 175],
  ];

  for (const topic of foundations) {
    for (const prompt of prompts) {
      const questionNumber = questions.length + 1;
      const tiers = tierRanges.filter(([, max]) => questionNumber <= max).map(([name]) => name);

      const questionPrompt = prompt.replace('{topic}', topic);

      questions.push({
        questionNumber,
        topic,
        prompt: questionPrompt,
        example: buildQuestionExample(questionNumber, topic, questionPrompt),
        tiers: tiers.length ? tiers : ['ALL_300'],
        intent: 'business-start-and-forward',
        active: true,
      });

      if (questions.length === limit) {
        return questions;
      }
    }
  }

  return questions;
}

export function buildEmailLetters(limit = 360) {
  const letters = [];
  const subjects = [
    'Welcome to KnoUKno',
    'Your business title is ready',
    'Finish your next five questions',
    'Your plan is getting stronger',
    'Review your grade and rate',
    'Print your business page',
    'Save your answers today',
    'Your next founder step',
    'Member questions are ready',
    'Pro planning is ready',
    'Bonus questions are open',
    'Keep moving the business forward',
  ];

  for (let index = 1; index <= limit; index += 1) {
    const subject = subjects[(index - 1) % subjects.length];
    const step = foundations[(index - 1) % foundations.length];

    letters.push({
      emailNumber: index,
      subject: `${subject} #${index}`,
      body: `Hello {{clientName}}, this is KnoUKno email ${index}. Today focus on ${step}. Open your dashboard, review the title, answer the next question, save the page, and move one practical step forward.`,
      audience: index % 3 === 0 ? 'pro' : index % 2 === 0 ? 'member' : 'free',
      active: true,
      createdAt: new Date(),
    });
  }

  return letters;
}
