import { MongoClient } from 'mongodb';

const uri = process.env.MONGODB_URI;
const databaseName = process.env.MONGODB_DB || 'knoukno';

if (!uri) {
  throw new Error('MONGODB_URI is required. Copy .env.example to .env and set a MongoDB connection string.');
}

const client = new MongoClient(uri);
let database;

export async function getDb() {
  if (!database) {
    await client.connect();
    database = client.db(databaseName);
  }

  return database;
}

export async function closeDb() {
  await client.close();
  database = undefined;
}
