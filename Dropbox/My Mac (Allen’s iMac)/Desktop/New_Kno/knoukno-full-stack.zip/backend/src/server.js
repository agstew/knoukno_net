import 'dotenv/config';
import bcrypt from 'bcryptjs';
import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import { ObjectId } from 'mongodb';
import { v4 as uuidv4 } from 'uuid';
import { getDb } from './db.js';
import { buildBusinessQuestions, buildEmailLetters } from './questionBank.js';
import { collectionNames, ensureSchema } from './schema.js';

const app = express();
const port = Number(process.env.PORT || 5050);
const corsOrigins = (process.env.CORS_ORIGIN || 'http://localhost:8080,http://localhost:5174')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);
const jwtSecret = process.env.JWT_SECRET || 'knoukno-local-development-secret';
const jwtExpiresIn = process.env.JWT_EXPIRES_IN || '7d';

app.use(helmet());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(cors({ origin: corsOrigins, credentials: true }));
app.use(express.json({ limit: '1mb' }));

function createToken(email) {
  return jwt.sign(
    {
      email,
      role: email === 'admin@knoukno.net' ? 'admin' : 'client',
    },
    jwtSecret,
    {
      subject: email,
      expiresIn: jwtExpiresIn,
      issuer: 'knoukno-api',
    },
  );
}

function getBearerToken(request) {
  const authorization = String(request.header('authorization') || '').trim();

  if (!authorization.toLowerCase().startsWith('bearer ')) {
    return '';
  }

  return authorization.slice(7).trim();
}

function requireUserId(request, response, next) {
  const token = getBearerToken(request);

  if (token) {
    try {
      const decoded = jwt.verify(token, jwtSecret, { issuer: 'knoukno-api' });
      request.userId = String(decoded.sub || decoded.email || '').trim();
      request.auth = decoded;
      next();
      return;
    } catch (_error) {
      response.status(401).json({ error: 'Invalid or expired token.' });
      return;
    }
  }

  const userId = String(request.header('x-knoukno-user-id') || request.body.userId || request.query.userId || '').trim();

  if (!userId) {
    response.status(401).json({ error: 'userId is required.' });
    return;
  }

  request.userId = userId;
  request.auth = { sub: userId, role: 'preview' };
  next();
}

function toObjectId(id) {
  return ObjectId.isValid(id) ? new ObjectId(id) : id;
}

app.get('/health', (_request, response) => {
  response.json({ ok: true, service: 'knoukno-mongodb-backend' });
});

async function runSetup(_request, response) {
  const db = await getDb();
  await ensureSchema(db);

  const questions = buildBusinessQuestions(300);
  const emailLetters = buildEmailLetters(360);
  await db.collection(collectionNames.questions).bulkWrite(
    questions.map((question) => ({
      updateOne: {
        filter: { questionNumber: question.questionNumber },
        update: { $set: question },
        upsert: true,
      },
    })),
  );

  await db.collection(collectionNames.examples).bulkWrite(
    questions.map((question) => ({
      updateOne: {
        filter: { questionNumber: question.questionNumber },
        update: { $set: { questionNumber: question.questionNumber, example: question.example, topic: question.topic, tiers: question.tiers, active: true } },
        upsert: true,
      },
    })),
  );

  await db.collection(collectionNames.emailLetters).bulkWrite(
    emailLetters.map((letter) => ({
      updateOne: {
        filter: { emailNumber: letter.emailNumber },
        update: { $set: letter },
        upsert: true,
      },
    })),
  );

  response.json({ ok: true, collections: Object.values(collectionNames), questions: questions.length, examples: questions.length, emailLetters: emailLetters.length });
}

app.get('/setup', runSetup);
app.post('/setup', runSetup);

app.post('/register', async (request, response) => {
  const db = await getDb();
  const email = String(request.body.email || '').trim().toLowerCase();
  const password = String(request.body.password || '');

  if (!email) {
    response.status(400).json({ error: 'email is required.' });
    return;
  }

  const passwordHash = password ? await bcrypt.hash(password, 12) : '';
  const eventId = uuidv4();
  await db.collection(collectionNames.registrations).insertOne({ eventId, email, hasPassword: Boolean(passwordHash), createdAt: new Date() });
  await db.collection(collectionNames.emails).updateOne(
    { email },
    {
      $setOnInsert: { email, createdAt: new Date() },
      $set: { updatedAt: new Date(), ...(passwordHash ? { passwordHash } : {}) },
    },
    { upsert: true },
  );

  response.json({ ok: true, eventId, email, token: createToken(email), tokenType: 'Bearer', expiresIn: jwtExpiresIn });
});

app.post('/login', async (request, response) => {
  const db = await getDb();
  const email = String(request.body.email || '').trim().toLowerCase();
  const password = String(request.body.password || '');

  if (!email) {
    response.status(400).json({ error: 'email is required.' });
    return;
  }

  const account = await db.collection(collectionNames.emails).findOne({ email });
  const hasPassword = Boolean(account?.passwordHash);
  const passwordOk = hasPassword ? await bcrypt.compare(password, account.passwordHash) : true;
  const eventId = uuidv4();

  await db.collection(collectionNames.logins).insertOne({ eventId, email, createdAt: new Date(), success: passwordOk, hasPassword });

  if (!passwordOk) {
    response.status(401).json({ error: 'Login failed. Check your details and try again.' });
    return;
  }

  response.json({ ok: true, eventId, email, token: createToken(email), tokenType: 'Bearer', expiresIn: jwtExpiresIn });
});

app.get('/me', requireUserId, (request, response) => {
  response.json({ ok: true, userId: request.userId, role: request.auth?.role || 'client' });
});

app.post('/payments', requireUserId, async (request, response) => {
  const db = await getDb();
  const payment = {
    userId: request.userId,
    tier: request.body.tier || 'FREE',
    amount: Number(request.body.amount || 0),
    status: request.body.status || 'pending',
    checkoutUrl: request.body.checkoutUrl || '',
    createdAt: new Date(),
  };
  const result = await db.collection(collectionNames.payments).insertOne(payment);

  response.status(201).json({ ...payment, _id: result.insertedId });
});

app.post('/titles', requireUserId, async (request, response) => {
  const db = await getDb();
  const title = {
    userId: request.userId,
    title: String(request.body.title || '').trim(),
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  const result = await db.collection(collectionNames.titles).insertOne(title);

  response.status(201).json({ ...title, _id: result.insertedId });
});

app.get('/titles', requireUserId, async (request, response) => {
  const db = await getDb();
  const titles = await db.collection(collectionNames.titles).find({ userId: request.userId }).sort({ createdAt: -1 }).toArray();

  response.json({ titles });
});

app.get('/questions', async (request, response) => {
  const db = await getDb();
  const page = Math.max(1, Number(request.query.page || 1));
  const limit = Math.min(50, Math.max(1, Number(request.query.limit || 5)));
  const tier = String(request.query.tier || '').trim().toUpperCase();
  const filter = tier && tier !== 'ALL_300' ? { active: true, tiers: tier } : { active: true };
  const questions = await db.collection(collectionNames.questions)
    .find(filter)
    .sort({ questionNumber: 1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .toArray();

  response.json({ page, limit, questions });
});

app.get('/examples', async (request, response) => {
  const db = await getDb();
  const page = Math.max(1, Number(request.query.page || 1));
  const limit = Math.min(50, Math.max(1, Number(request.query.limit || 5)));
  const examples = await db.collection(collectionNames.examples)
    .find({ active: true })
    .sort({ questionNumber: 1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .toArray();

  response.json({ page, limit, examples });
});

app.get('/email-letters', async (request, response) => {
  const db = await getDb();
  const page = Math.max(1, Number(request.query.page || 1));
  const limit = Math.min(60, Math.max(1, Number(request.query.limit || 12)));
  const letters = await db.collection(collectionNames.emailLetters)
    .find({ active: true })
    .sort({ emailNumber: 1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .toArray();

  response.json({ page, limit, letters });
});

app.post('/answers', requireUserId, async (request, response) => {
  const db = await getDb();
  const answer = {
    userId: request.userId,
    titleId: toObjectId(request.body.titleId),
    questionNumber: Number(request.body.questionNumber),
    answer: String(request.body.answer || ''),
    updatedAt: new Date(),
  };

  await db.collection(collectionNames.answers).updateOne(
    { userId: answer.userId, titleId: answer.titleId, questionNumber: answer.questionNumber },
    { $set: answer, $setOnInsert: { createdAt: new Date() } },
    { upsert: true },
  );

  response.json({ ok: true, answer });
});

app.post('/ratings', requireUserId, async (request, response) => {
  const db = await getDb();
  const rating = {
    userId: request.userId,
    titleId: toObjectId(request.body.titleId),
    questionNumber: Number(request.body.questionNumber),
    rating: Math.max(0, Math.min(5, Number(request.body.rating || 0))),
    updatedAt: new Date(),
  };

  await db.collection(collectionNames.ratings).updateOne(
    { userId: rating.userId, titleId: rating.titleId, questionNumber: rating.questionNumber },
    { $set: rating, $setOnInsert: { createdAt: new Date() } },
    { upsert: true },
  );

  response.json({ ok: true, rating });
});

app.post('/grades', requireUserId, async (request, response) => {
  const db = await getDb();
  const titleId = toObjectId(request.body.titleId);
  const answered = await db.collection(collectionNames.answers).countDocuments({ userId: request.userId, titleId, answer: { $ne: '' } });
  const grade = Math.round((answered / 5) * 100);
  const gradeDoc = { userId: request.userId, titleId, grade, answered, createdAt: new Date() };

  await db.collection(collectionNames.grades).insertOne(gradeDoc);
  response.json(gradeDoc);
});

app.post('/averages', requireUserId, async (request, response) => {
  const db = await getDb();
  const titleId = toObjectId(request.body.titleId);
  const ratings = await db.collection(collectionNames.ratings).find({ userId: request.userId, titleId }).toArray();
  const rateAverage = ratings.length ? ratings.reduce((sum, doc) => sum + Number(doc.rating || 0), 0) / ratings.length : 0;
  const latestGrade = await db.collection(collectionNames.grades).find({ userId: request.userId, titleId }).sort({ createdAt: -1 }).limit(1).next();
  const average = Math.round(((latestGrade?.grade || 0) + (rateAverage / 5) * 100) / 2);
  const averageDoc = { userId: request.userId, titleId, rateAverage: Number(rateAverage.toFixed(1)), average, createdAt: new Date() };

  await db.collection(collectionNames.averages).insertOne(averageDoc);
  response.json(averageDoc);
});

app.post('/saves', requireUserId, async (request, response) => {
  const db = await getDb();
  await db.collection(collectionNames.saves).insertOne({ userId: request.userId, titleId: toObjectId(request.body.titleId), type: request.body.type || 'page', createdAt: new Date() });
  response.json({ ok: true });
});

app.post('/save-all', requireUserId, async (request, response) => {
  const db = await getDb();
  const titleId = toObjectId(request.body.titleId);
  await db.collection(collectionNames.saves).insertOne({ userId: request.userId, titleId, type: 'all', createdAt: new Date() });
  response.json({ ok: true, saved: 'all' });
});

app.post('/prints', requireUserId, async (request, response) => {
  const db = await getDb();
  await db.collection(collectionNames.prints).insertOne({ userId: request.userId, titleId: toObjectId(request.body.titleId), createdAt: new Date() });
  response.json({ ok: true });
});

app.delete('/titles/:titleId', requireUserId, async (request, response) => {
  const db = await getDb();
  const titleId = toObjectId(request.params.titleId);
  await db.collection(collectionNames.deletes).insertOne({ userId: request.userId, titleId, createdAt: new Date() });
  await db.collection(collectionNames.titles).deleteOne({ userId: request.userId, _id: titleId });
  response.json({ ok: true });
});

app.listen(port, async () => {
  const db = await getDb();
  await ensureSchema(db);
  console.log(`KnoUKno MongoDB backend running on http://localhost:${port}`);
});
