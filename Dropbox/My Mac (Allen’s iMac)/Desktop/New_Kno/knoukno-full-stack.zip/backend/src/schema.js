export const collectionNames = {
  payments: 'payments',
  titles: 'titles',
  logins: 'logins',
  registrations: 'registrations',
  prints: 'prints',
  saves: 'saves',
  questions: 'questions',
  examples: 'examples',
  grades: 'grades',
  ratings: 'ratings',
  answers: 'answers',
  averages: 'averages',
  deletes: 'deletes',
  emails: 'emails',
  emailLetters: 'emailLetters',
};

export async function ensureSchema(db) {
  const existing = new Set((await db.listCollections().toArray()).map((collection) => collection.name));

  for (const name of Object.values(collectionNames)) {
    if (!existing.has(name)) {
      await db.createCollection(name);
    }
  }

  try {
    await db.collection(collectionNames.emails).dropIndex('email_1');
  } catch (error) {
    // Index may not exist yet.
  }

  await Promise.all([
    db.collection(collectionNames.titles).createIndex({ userId: 1, createdAt: -1 }),
    db.collection(collectionNames.questions).createIndex({ questionNumber: 1 }, { unique: true }),
    db.collection(collectionNames.questions).createIndex({ tiers: 1, questionNumber: 1 }),
    db.collection(collectionNames.examples).createIndex({ questionNumber: 1 }, { unique: true }),
    db.collection(collectionNames.answers).createIndex({ userId: 1, titleId: 1, questionNumber: 1 }, { unique: true }),
    db.collection(collectionNames.grades).createIndex({ userId: 1, titleId: 1, createdAt: -1 }),
    db.collection(collectionNames.ratings).createIndex({ userId: 1, titleId: 1, questionNumber: 1 }, { unique: true }),
    db.collection(collectionNames.averages).createIndex({ userId: 1, titleId: 1, createdAt: -1 }),
    db.collection(collectionNames.payments).createIndex({ userId: 1, status: 1, createdAt: -1 }),
    db.collection(collectionNames.saves).createIndex({ userId: 1, titleId: 1, createdAt: -1 }),
    db.collection(collectionNames.prints).createIndex({ userId: 1, titleId: 1, createdAt: -1 }),
    db.collection(collectionNames.deletes).createIndex({ userId: 1, titleId: 1, createdAt: -1 }),
    db.collection(collectionNames.emails).createIndex({ email: 1 }, { unique: true, partialFilterExpression: { email: { $exists: true } } }),
    db.collection(collectionNames.emailLetters).createIndex({ emailNumber: 1 }, { unique: true }),
    db.collection(collectionNames.logins).createIndex({ email: 1, createdAt: -1 }),
    db.collection(collectionNames.registrations).createIndex({ email: 1, createdAt: -1 }),
  ]);
}
