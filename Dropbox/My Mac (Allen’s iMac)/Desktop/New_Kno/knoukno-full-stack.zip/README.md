# KnoUKno Full Stack Workspace

This workspace now has three parts:

- `knoukno-wordpress-theme/` - WordPress website and registered client dashboard.
- `backend/` - Node/Express MongoDB API for payments, titles, login/register events, print/save/question/grade/rating/answer/average/delete/email data.
- `admin-dashboard/` - React/Vite admin dashboard scaffold with the requested JSX pages.

## WordPress Website

```bash
docker compose -f docker-compose.local.yml up -d
open http://localhost:8080/
```

Public pages:

- `http://localhost:8080/` - Home with AI business planning cards, images, and 300+ words of homepage copy.
- `http://localhost:8080/about/` - About page with 750+ words.
- `http://localhost:8080/pricing/` - Free, Member, Pro, Member-Bonus, and Pro-Bonus tiers.
- `http://localhost:8080/login/` - Login.
- `http://localhost:8080/register/` - Register.
- `http://localhost:8080/forgot-password/` - Forgot Password reset form.

Registered client pages:

- Dashboard action buttons: Title, Answers, Question, Grade, Rated, Average, Save, Print, Save Answers, Save Grade, Save Rated, Average Save, Save All, Delete.
- Workspace pages: Title, Questions, Grade, Rate, Average.
- Title list flow: create a title, see it in the list, click the title name, and open `/questions/?business=...`.

## MongoDB Backend

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Local backend `.env` values:

```bash
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB=knoukno
PORT=5050
CORS_ORIGIN=http://localhost:8080,http://localhost:5174
JWT_SECRET=change-this-to-a-long-random-secret
JWT_EXPIRES_IN=7d
```

Create collections and seed 300 business-startup questions, 300 examples, and 360 client email letters:

```bash
curl -X POST http://localhost:5050/setup
```

Backend package includes Express, CORS, dotenv, JWT, bcryptjs, Helmet, express-rate-limit, MongoDB, Mongoose, EJS, UUID, Nodemailer, ngrok, and PayPal checkout support. Login and register return bearer tokens. If a password is sent to `/register`, it is stored as a bcrypt hash and checked on `/login`.

Collections created by setup/schema:

- `payments`
- `titles`
- `logins`
- `registrations`
- `prints`
- `saves`
- `questions`
- `examples`
- `grades`
- `ratings`
- `answers`
- `averages`
- `deletes`
- `emails`
- `emailLetters`

Question tiers:

- Free: 1 - 5 questions for 3 days.
- Member: 1 - 50 questions per month.
- Member-Bonus: 1 - 150 questions.
- Pro: 1 - 75 questions per year.
- Pro-Bonus: 1 - 175 questions.
- Bonus: $100.00 for bonus questions when buying now.

## Admin Dashboard

```bash
cd admin-dashboard
cp .env.example .env
npm install
npm run dev
```

Then open the Vite URL, usually `http://localhost:5174/`.

Build the admin dashboard with the same `.env` file:

```bash
npm run build
```
